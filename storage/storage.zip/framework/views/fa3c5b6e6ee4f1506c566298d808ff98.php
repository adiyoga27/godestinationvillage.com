<?php $__env->startSection('content-header'); ?>
    <div class="page-header">
        <h3 class="page-title">
          Manajemen User Admin
        </h3>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item">Administrator</li>
            <li class="breadcrumb-item active" aria-current="page">User Admin</li>
          </ol>
        </nav>
      </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <a href="<?php echo e(route('user_admin.create')); ?>" class="btn btn-lg btn-gradient-danger mr-2"> 
                  <i class="mdi mdi-plus-circle-outline"></i> Tambah User Admin
                </a>
                <br /><br />
                <div class="table-responsive"> 
                    <?php echo $html->table(['class'=>'table table-hover', 'style'=>'width:100%']); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $html->scripts(); ?>

    <?php echo $__env->make('components/_script_adjust-table', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/backend/admin/index.blade.php ENDPATH**/ ?>