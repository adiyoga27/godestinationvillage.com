<?php echo Form::model($model, ['url' => $delete, 'method' => 'delete', 'class' => 'form-inline js-confirm', 'data-confirm' => $confirm_message, 'onSubmit' => 'event.preventDefault(); return confirmDelete(this)'] ); ?>

<button class="btn btn-sm btn-outline-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-table-el="<?php echo e(empty($tableEl) ? '#dataTableBuilder' : $tableEl); ?>" data-padding="<?php echo e(empty($padding) ? '65px' : $padding); ?>" onclick="addPadding(this)">Action</button>
<div class="dropdown-menu">
    <?php $__currentLoopData = $url; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a class="dropdown-item" href="<?php echo e($data); ?>"><?php echo e($key); ?></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <div role="separator" class="dropdown-divider"></div>
  <?php echo Form::submit('Delete', ['class' => 'dropdown-item']); ?>

</div>
<?php echo Form::close(); ?><?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/datatable/_action_dinamyc.blade.php ENDPATH**/ ?>