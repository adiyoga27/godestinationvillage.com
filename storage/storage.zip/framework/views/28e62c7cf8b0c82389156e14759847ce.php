<?php $__env->startSection('content-header'); ?>
    <div class="page-header">
        <h3 class="page-title">
          Edit Profile
        </h3>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item">Administrator</li>
            <li class="breadcrumb-item active" aria-current="page">Edit Profile</li>
          </ol>
        </nav>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
              <h3 align="center">Edit Profile</h3>
                <hr />
                <?php echo Form::model($user, ['url' => route('update_profile'),
                    'method'=>'post', 'class'=>'form-sample', 'files' => true]); ?>

                    <?php if(Auth::user()->role_id == 1): ?>
                        <?php echo $__env->make('backend.profile.form._form_profile', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php else: ?>
                        <?php echo $__env->make('backend.village.form._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endif; ?>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php if(Auth::user()->role_id == 2): ?>
<?php echo $__env->make('backend.village.script.edit_js', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endif; ?>
<?php echo $__env->make('layouts.backend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/backend/profile/index.blade.php ENDPATH**/ ?>