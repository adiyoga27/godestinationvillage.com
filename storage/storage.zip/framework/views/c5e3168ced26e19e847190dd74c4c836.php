<?php $__env->startSection('content'); ?>
    <!-- start page title area-->
    <div class="page-title-area ptb-100">
        <div class="container">
            <div class="page-title-content">
                <h1>Board of Expert</h1>
                <ul>
                    <li class="item"><a href="/">Home</a></li>
                    <li class="item"><a href="#"><i class='bx bx-chevrons-right'></i>Board of Expert</a></li>
                </ul>
            </div>
        </div>
        <div class="bg-image">
            <img src="<?php echo e(url('assets/customer/img/page-title-area/team.jpg')); ?>" alt="Demo Image">
        </div>
    </div>
    <!-- end page title area -->

    <!-- start team section -->
    <section id="team" class="team-section ptb-100">
        <div class="container">
            
            <div class="row">
                <div class="team3">

                    <div class="row">
                        <?php $__currentLoopData = $boards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- column  -->
                            <div class="col-lg-4 mb-4">
                                <!-- Row -->
                                <div class="item-single ">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <img src="<?php echo e(url('storage')); ?>/board/<?php echo e($f->avatar); ?>" alt="wrapkit"
                                                class="img-fluid" />
                                        </div>
                                        <div class="col-md-12">
                                            <center>
                                                <h5 class="mt-4 font-weight-medium mb-0"><?php echo e($f->name); ?></h5>
                                                <h6 class="subtitle">( <?php echo e($f->title); ?> )</h6>
                                            </center>
                                            <div class="ml-4 mr-4 description">
                                                <?php echo $f->description; ?>

                                            </div>
                                            <br>
                                            <center>
                                                <div class="social-link">
                                                    <?php if(!empty($f->phone)): ?>
                                                    <a href="tel:<?php echo e($f->phone); ?>" target="_blank"><i
                                                            class='bx bxs-phone-call'></i></a>
                                                <?php endif; ?>
                                                <?php if(!empty($f->whatsapp)): ?>
                                                    <a href="https://wa.me/<?php echo e($f->whatsapp); ?>" target="_blank"><i
                                                            class='bx bxl-whatsapp'></i></a>
                                                <?php endif; ?>
                                                <?php if(!empty($f->facebook)): ?>
                                                    <a href="<?php echo e($f->facebook); ?>" target="_blank"><i
                                                            class='bx bxl-facebook'></i></a>
                                                <?php endif; ?>
                                                <?php if(!empty($f->instagram)): ?>
                                                    <a href="<?php echo e($f->instagram); ?>" target="_blank"><i
                                                            class='bx bxl-instagram'></i></a>
                                                <?php endif; ?>
                                                <?php if(!empty($f->twitter)): ?>
                                                    <a href="<?php echo e($f->twitter); ?>" target="_blank"><i
                                                            class='bx bxl-twitter'></i></a>
                                                <?php endif; ?>
                                                <?php if(!empty($f->linkedin)): ?>
                                                    <a href="<?php echo e($f->linkedin); ?>" target="_blank"><i
                                                            class='bx bxl-linkedin'></i></a>
                                                <?php endif; ?>


                                                </div>
                                            </center>
                                            <br>
                                        </div>
                                    </div>

                                </div>
                                <!-- Row -->
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- column  -->
                        <!-- column  -->

                        <!-- column  -->
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- end team section -->
<?php $__env->stopSection(); ?>
<script>
      document.addEventListener("DOMContentLoaded", function() {
        var paragraphs = document.querySelectorAll(".description");

        paragraphs.forEach(function(paragraph) {
            var text = paragraph.textContent;
            var truncatedText = text.slice(0, 200);
            var lastSpaceIndex = truncatedText.lastIndexOf(" ");
            var lastWordTruncated = truncatedText.slice(lastSpaceIndex);
            var isFullText = false;

            if (text.length > 200) {
                var truncatedContent = truncatedText.slice(0, lastSpaceIndex) + "...";
                paragraph.textContent = truncatedContent;

                var readMoreLink = document.createElement("a");
                readMoreLink.textContent = "Read More";
                readMoreLink.setAttribute("href", "#");
                readMoreLink.style.color = "red"; // Set color to red

                readMoreLink.addEventListener("click", function(e) {
                    e.preventDefault();
                    if (isFullText) {
                        paragraph.textContent = truncatedContent + " ";
                        readMoreLink.textContent = "Read More";
                        isFullText = false;
                    } else {
                        paragraph.textContent = text;
                        readMoreLink.textContent = "Hide More";
                        isFullText = true;
                    }
                });

                paragraph.appendChild(readMoreLink);
            }
        });
    });
</script>

<?php echo $__env->make('customer/layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/customer/boardexpert.blade.php ENDPATH**/ ?>