<?php $__env->startSection('content'); ?>
    <style>
        .bor {
            border: 1px solid grey;
            padding: 20px
        }

    </style>
    <!-- start page title area-->
    <div class="page-title-area ptb-100">
        <div class="container">
            <div class="page-title-content">
                <h1>Bank Reservation </h1>
                <ul>
                    <li class="item"><a href="index.html">Home</a></li>
                    <li class="item"><a href="#"><i class='bx bx-chevrons-right'></i>Reservation </a>
                    <li class="item"><a href="#"><i class='bx bx-chevrons-right'></i>Bank </a>

                    </li>
                </ul>
            </div>
        </div>
        <div class="bg-image">
            <img src="<?php echo e(url('assets/customer/img/page-title-area/privacy.jpg')); ?>" alt="Demo Image">
        </div>
    </div>
    <!-- end page title area -->
    <section class="privacy-policy ptb-100">
        <div class="container">
            <div class="row">
                <div class="col-md-12  ftco-animate">
                    <h4>Your Reservation List</h4>
                </div>
                <div class="col-lg-4">
                    <aside class="widget-area">
                        <section class="widget">
                            <ul>
                                <?php if (isset(Auth::user()->email)) {
                                $email = Auth::user()->email;
                                } else {
                                $email = $isiemail;
                                } ?>
                                <li><a href="<?php echo e(url('reservation/' . $email)); ?>"><i
                                            class='bx bx-chevron-right'></i>Unpaid</a></li>
                                <li><a href="<?php echo e(url('reservation/paid/' . $email)); ?>"><i
                                            class='bx bx-chevron-right'></i>Paid</a></li>
                                <li><a href="<?php echo e(url('reservation/paypal/' . $email)); ?>"><i
                                            class='bx bx-chevron-right'></i>Paypal</a></li>
                                <li><a href="<?php echo e(url('reservation/bank/' . $email)); ?>" class="active"><i
                                            class='bx bx-chevron-right'></i>Bank Transfer</a></li>
                                <li><a href="<?php echo e(url('reservation/cancel/' . $email)); ?>"><i
                                            class='bx bx-chevron-right'></i>Canceled</a></li>
                                </li>
                            </ul>
                        </section>
                    </aside>
                </div>
                <div class="col-lg-8 col-md-12">
                    <div class="content">
                        <div class="col-md-12">
                            <?php if(count($order) == 0): ?>
                                <h3>
                                    No Transactions </h3>
                            <?php endif; ?>
                            <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row bor">
                                    <div class="col-md-3">
                                        <img src="<?php echo e(url('storage/packages/' . $orders->package->default_img)); ?>"
                                            width="100%" alt="">
                                    </div>
                                    <div class="col-md-9">
                                        <h3><?php echo e($orders->package_name); ?></h3>
                                        <hr>

                                        <h6> <?php echo e($orders->package->category->name); ?></h6>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <i class="fa fa-address-book"></i> <?php echo e($orders->pax); ?> Peoples
                                            </div>
                                            <div class="col-md-6">
                                                <i class="fa fa-industry"></i> <?php echo e($orders->checkin_date); ?>

                                            </div>
                                            <div class="col-md-12">
                                                <b style="padding-top:10px; display:block;">Special notes :</b>
                                                <p><?php echo e($orders->special_note); ?></p>
                                            </div>
                                            <div class="col-md-12">
                                                <hr>
                                                <button class="btn btn-warning">PAID</button>
                                                <button class="btn btn-danger">With BANK TRANSFER</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if(count($order) > 0): ?>

                                <div class="item col-md-12">
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12">
                                            <div class="pagination text-center">


                                                <?php for($i = 1; $i <= $order->lastPage(); $i++): ?>
                                                    <a href="<?php echo e($order->url($i)); ?>" class="page-numbers <?php if($order->currentPage() == $i): ?> current <?php endif; ?>">

                                                        <?php echo e($i); ?>

                                                    </a>
                                                <?php endfor; ?>
                                                <?php if($order->lastPage() > 1): ?>
                                                    <a href="<?php echo e($order->nextPageUrl()); ?>" class="page-numbers">Next</a>

                                                <?php endif; ?>
                                                
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<script
    src="https://www.paypal.com/sdk/js?client-id=AWqwc4AETYKPOwQioHYGRXZAFeAcSrSB6BhSEpSHzq2c3UdafPYHin9Zdy0SXRlo_EzmmYxevXBlv_xV">
</script>
<script>
</script>

<?php echo $__env->make('customer/layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/customer/reservation/bank.blade.php ENDPATH**/ ?>