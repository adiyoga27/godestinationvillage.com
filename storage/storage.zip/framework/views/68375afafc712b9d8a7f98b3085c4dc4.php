<?php
   $public = env('PUBLIC_VARIABLE_URL', "");
?>


    
    

<?php echo Form::model($model , ['url' => isset($delete) ? $delete : '', 'method' => 'delete', 'class' => 'form-inline js-confirm', 'data-confirm' => isset($confirm_message) ? $confirm_message : '']); ?>

    <div class="btn-group btn-group--dart">
        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <?php echo app('translator')->get('datatable.dropdown.actions'); ?> <span class="caret"></span>
        </button>
        <ul class="dropdown-menu">
            
            <?php $__currentLoopData = $url; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e($data['link']); ?>" data-source="<?php echo e($id); ?>" class="<?php echo e($data['class']); ?>"><?php echo e($key); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if(isset($delete)): ?>
                <li>
                    <?php echo Form::submit(trans('datatable.dropdown.delete'), ['class' => 'btn btn-danger']); ?>

                </li>
            <?php endif; ?>
        </ul>
        
    </div>
<?php echo Form::close(); ?>

<?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/datatable/_action_show_ajax.blade.php ENDPATH**/ ?>