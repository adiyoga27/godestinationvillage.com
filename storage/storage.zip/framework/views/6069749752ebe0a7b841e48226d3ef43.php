<!DOCTYPE html>
<html lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <!-- Required meta tags -->
  
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title><?php echo e(config('app.name', 'Godestinationvillage - Administrator')); ?></title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo e(url('assets/customer/dist/vendors/iconfonts/mdi/css/materialdesignicons.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('assets/customer/dist/vendors/css/vendor.bundle.base.css')); ?>">
  <!-- endinject -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo e(url('assets/customer/dist/css/style.css')); ?>">
  
  <link rel="stylesheet" href="<?php echo e(url('assets/customer/dist/css/rating.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/select2.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('node_modules/@ttskch/select2-bootstrap4-theme/dist/select2-bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/css/bootstrap-select.css" />
  <!-- endinject -->
  <link rel="apple-touch-icon" sizes="120x120" href="<?php echo e(asset('favicons/apple-touch-icon.png')); ?>">
  <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('favicons/favicon-32x32.png')); ?>">
  <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('favicons/favicon-16x16.png')); ?>">
  <link rel="manifest" href="<?php echo e(asset('favicons/site.webmanifest')); ?>">
  <link rel="mask-icon" href="<?php echo e(asset('favicons/safari-pinned-tab.svg')); ?>" color="#5bbad5">
  <meta name="msapplication-TileColor" content="#da532c">
  <meta name="theme-color" content="#ffffff">

  <link href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css" rel="stylesheet">

  
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

  <?php echo $__env->yieldContent('style'); ?>
</head>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
        <a class="navbar-brand brand-logo" href="<?php echo e(url('administrator/dashboard')); ?>"><img style="width: 115px; height: auto" src="<?php echo e(url('assets/customer/dist/images/logo.png')); ?>" alt="logo"/></a>
        <a class="navbar-brand brand-logo-mini" href="<?php echo e(url('administrator/dashboard')); ?>"><img style="height: 65px !important" src="<?php echo e(url('assets/customer/dist/images/icon.png')); ?>" alt="logo"/></a>
      </div>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      
      <!-- partial -->
      
        <div class="content-wrapper">
          <?php echo $__env->yieldContent('content-header'); ?>
          <?php echo $__env->make('components.alert', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
          <?php echo $__env->yieldContent('content'); ?>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        
        <!-- partial -->
      
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <div class="modal fade" id="confirm" tabindex="-1" role="dialog" aria-labelledby="confirm-label" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="confirm-label"></h5>
          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        </div>
        <div class="modal-body">
          <span class="message"></span>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-primary dismiss" data-dismiss="modal"></button>
          <button type="button" class="btn btn-danger confirm" data-dismiss="modal"></button>
        </div>
      </div>
    </div>
  </div>


  <!-- plugins:js -->
  <script src="<?php echo e(url('assets/customer/dist/vendors/js/vendor.bundle.base.js')); ?>"></script>
  <script src="<?php echo e(url('assets/customer/dist/vendors/js/vendor.bundle.addons.js')); ?>"></script>
  <script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="<?php echo e(url('assets/customer/dist/js/off-canvas.js')); ?>"></script>
  <script src="<?php echo e(url('assets/customer/dist/js/misc.js')); ?>"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?php echo e(url('assets/customer/dist/js/dashboard.js')); ?>"></script>
  <script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/js/bootstrap-select.min.js"></script>
  <!-- End custom js for this page-->
  <?php echo $__env->make('components/_script_modal-delete', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <?php echo $__env->yieldContent('js'); ?>
</body>

</html>
<?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/layouts/backend_out.blade.php ENDPATH**/ ?>