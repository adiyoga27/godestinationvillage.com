<html>
    <script async src="https://talk.hyvor.com/embed/embed.js" type="module"></script>
    <hyvor-talk-comments
        website-id="12135"
        page-id="<?php echo e($blog->slug); ?>"
    ></hyvor-talk-comments>
    </html><?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/customer/comment.blade.php ENDPATH**/ ?>