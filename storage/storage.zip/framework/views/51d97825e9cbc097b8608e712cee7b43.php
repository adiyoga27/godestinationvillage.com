<?php $__env->startSection('style'); ?>
<style>
    @media print {
        footer {
            display: none;
        }

        nav {
            display: none;
        }

        .btn {
            display: none;
        }

        .navbar {
            display: none !important;
        }

        label {
            display: none !important;
        }
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    function printDiv(divName) {
        window.print();
    }
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="pull-right">
                <?php if($order->payment_status == 'pending'): ?>
                
                <button class="btn btn-lg btn-gradient-danger mb-2" onclick="printDiv('print');"><i class="mdi mdi-printer"></i> Print Invoice</button>
                <?php elseif($order->payment_status == 'success'): ?>
                
                <button class="btn btn-lg btn-gradient-danger mb-2" onclick="printDiv('print');"><i class="mdi mdi-printer"></i> Print Voucher</button>
                <?php elseif($order->payment_status == 'cancel'): ?>
                
                <button class="btn btn-lg btn-gradient-danger mb-2" onclick="printDiv('print');"><i class="mdi mdi-printer"></i> Print Invoice</button>
                <?php endif; ?>
            </div>
            <?php if($order->payment_status == 'pending'): ?>
            <h1>Invoice</h1>
            <?php elseif($order->payment_status == 'success'): ?>
            <h1>Voucher</h1>
            <?php elseif($order->payment_status == 'cancel'): ?>
            <h1>Invoice</h1>
            <?php endif; ?>

        </div>
    </div>
    <br />
    <div class="card" id="print">
        <div class="card-header">
            Order No. :
            <strong><?php echo e($order->code); ?></strong>
            <span class="float-right"> <strong>Order Date :</strong> <?php echo e(date('d/m/Y', strtotime($order->created_at))); ?></span>
        </div>
        <div class="card-body">
            <div class="row mb-4">
                <div class="col-sm-12">
                    <span><strong>Arrival Date :</strong> <?php echo e(date('d/m/Y', strtotime($order->checkin_date))); ?></span><br /><br /><br />
                </div>
                <div class="col-sm-6">
                    <h6 class="mb-3"><strong>Customer:</strong></h6>

                    <div>
                        <?php echo e($order->customer_name); ?>

                    </div>
                    <div><?php echo e($order->customer_address); ?></div>
                    <div>Email : <?php echo e($order->customer_email); ?></div>
                    <div>Phone : <?php echo e($order->customer_phone); ?></div>

                </div>

                <div class="col-sm-6">
                    <h6 class="mb-3"><strong>Company :</strong></h6>
                    <div>
                        Godestiantion Village
                    </div>
                    <div>Jln Wr Supratman No. 302 Denpasar Timur, Bali</div>
                    <div>Website: <?php echo e(env('APP_URL')); ?> </div>
                    <div>Email : <?php echo e(env('APP_EMAIL')); ?> </div>
                    <div>Phone : 081938834675</div>
                    <br />

                </div>
                <div class="col-sm-6">
                    <br />
                    <h6 class="mb-3"><strong>Special Note</strong></h6> <?php echo $order->special_note; ?>

                </div>
                <div class="col-sm-6">
                    <div style="margin-top: 10px"></div>
                    <h6 class="mb-3"><strong>Payment:</strong></h6>
                    <div>
                        <strong><?php echo e(str_replace('_', ' ', strtoupper($order->payment_type))); ?></strong> &nbsp;&nbsp;
                        <?php if($order->payment_status == 'pending'): ?>
                            <label class='badge badge-gradient-warning'>Pending</label>
                        <?php elseif($order->payment_status == 'success'): ?>
                            <label class='badge badge-gradient-success'>Success</label>
                        <?php elseif($order->payment_status == 'cancel'): ?>
                            <label class='badge badge-gradient-danger'>Declined</label>
                        <?php endif; ?>
                    </div>
                    <?php if($order->payment_type == 'bank_transfer'): ?>
                        <div><strong><?php echo e($order->bank_account->bank_name); ?>

                                <?php echo e($order->bank_account->bank_acc_no); ?></strong> a/n
                            <?php echo e($order->bank_account->bank_acc_name); ?></div>
                    <?php endif; ?>
                </div>

               
            </div>

            <div class="table-responsive-sm">
                <table class="table table-striped">
                
                    <tr>
                        <td>Name of Homestay</td>
                        <td><?php echo e($order->homestay_name); ?></td>
                    </tr>
                    <tr>
                        <td>People(s)</td>
                        <td><?php echo e($order->pax); ?> Pax</td>
                    </tr>
                    <tr>
                        <td>Price of Homestay</td>
                        <td><?php echo e(number_format($order->homestay_price, 2,'.',',')); ?></td>
                    </tr>
                    <tr>
                        <td>Discount</td>
                        <td> <?php echo e(number_format($order->homestay_discount, 2,'.',',')); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Payment Total</strong></td>
                        <td><strong><?php echo e(number_format($order->total_payment, 2,'.',',')); ?></strong></td>
                    </tr>
                </table>
            </div>

        </div>
    </div>
    <br />
    

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend_out', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/backend/homestay/order/invoice.blade.php ENDPATH**/ ?>