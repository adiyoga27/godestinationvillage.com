

<div class="row">
    <div class="col-md-12">
        <?php if(Auth::user()->role_id == 1): ?>
            <div class="form-group row">
                <label class="col-sm-3 col-form-label">Desa Wisata (*)</label>
                <div class="col-sm-9">
                    <?php echo Form::select('user_id', $villages, null, ['class' => 'selectpicker', 'required' => 'required', 'data-live-search' => 'true']); ?>

                    <?php echo $errors->first('user_id', '<p class="text-danger">:message</p>'); ?>

                </div>
            </div>
        <?php else: ?>
            <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
        <?php endif; ?>

        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Kategori Paket (*)</label>
            <div class="col-sm-9">
                <?php echo Form::select('category_id', $categories, null, ['class' => 'selectpicker', 'required' => 'required', 'data-live-search' => 'true']); ?>

                <?php echo $errors->first('category_id', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>

        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Tag Paket (*)</label>
            <div class="col-sm-9">
                <?php echo Form::select('tag_id', $tags, null, ['class' => 'selectpicker', 'required' => 'required', 'data-live-search' => 'true']); ?>

                <?php echo $errors->first('tag_id', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>

        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Nama Paket (*)</label>
            <div class="col-sm-9">
                <label>English : </label>
                <?php echo Form::text('name', null, ['class' => 'form-control', 'required' => 'required']); ?>

                <?php echo $errors->first('name', '<p class="text-danger">:message</p>'); ?>

            </div>

        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label"></label>
            <div class="col-sm-9">
                <label>Indonesia : </label>
                <?php echo Form::text('name_id', $packageTranslate->name ?? null, ['class' => 'form-control', 'required' => 'required']); ?>

                <?php echo $errors->first('name_id', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>

        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Harga Paket (*)</label>
            <div class="col-sm-9">
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text bg-danger text-white">IDR</span>
                    </div>
                    <?php echo Form::number('price', null, ['class' => 'form-control', 'required' => 'required']); ?>

                </div>
                <?php echo $errors->first('price', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>

        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Diskon Paket (*)</label>
            <div class="col-sm-9">
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text bg-danger text-white">IDR</span>
                    </div>
                    <?php echo Form::number('disc', null, ['class' => 'form-control', 'required' => 'required']); ?>

                </div>
                <?php echo $errors->first('disc', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>

        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Default Image</label>
            <div class="col-sm-9">
                <input type="file" name="default_img" class="form-control">
                <?php echo $errors->first('default_img', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>

        

        

        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Deskripsi (*)</label>
            <div class="col-sm-9">
                <label>English : </label>
                <?php echo Form::textarea('desc', null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('desc', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label"></label>
            <div class="col-sm-9">
                <label>Indonesia : </label>
                <?php echo Form::textarea('desc_id', $packageTranslate->desc ?? null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('desc_id', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>

        

        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Itenaries</label>
            <div class="col-sm-9">
                <label>English : </label>
                <?php echo Form::textarea('itenaries', null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('itenaries', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label"></label>
            <div class="col-sm-9">
                <label>Indonesia : </label>
                <?php echo Form::textarea('itenaries_id', $packageTranslate->itenaries ?? null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('itenaries_id', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>


        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Inclusion</label>
            <div class="col-sm-9">
                <label>English : </label>

                <?php echo Form::textarea('inclusion', null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('inclusion', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label"></label>
            <div class="col-sm-9">
                <label>Indonesia : </label>

                <?php echo Form::textarea('inclusion_id', $packageTranslate->inclusion ?? null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('inclusion_id', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>

        

        

        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Term & Condition</label>
            <div class="col-sm-9">
                <label>English : </label>

                <?php echo Form::textarea('term', null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('term', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label"></label>
            <div class="col-sm-9">
                <label>Indonesia : </label>

                <?php echo Form::textarea('term_id', $packageTranslate->term ?? null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('term_id', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>

        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Durasi</label>
            <div class="col-sm-9">
                <label>English : </label>

                <?php echo Form::textarea('duration', null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('duration', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label"></label>
            <div class="col-sm-9">
                <label>Indonesia : </label>

                <?php echo Form::textarea('duration_id', $packageTranslate->duration ?? null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('duration_id', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>

        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Perisapan Yang Diperlukan</label>
            <div class="col-sm-9">
                <label>English : </label>

                <?php echo Form::textarea('preparation', null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('preparation', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label"></label>
            <div class="col-sm-9">
                <label>Indonesia : </label>

                <?php echo Form::textarea('preparation_id', $packageTranslate->preparation ?? null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('preparation_id', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
        <?php if(Auth::user()->role_id == 1): ?>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Status (*)</label>
            <div class="col-sm-4">
                <div class="form-check">
                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="is_active" value="1" <?php if(empty($package)): ?> checked=""
                    <?php else: ?>
                        <?php if($package->is_active == 1): ?>
                            checked="" <?php endif; ?>
                        <?php endif; ?>
                        >
                        Aktif
                        <i class="input-helper"></i>
                    </label>
                </div>
            </div>
            <div class="col-sm-5">
                <div class="form-check">
                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="is_active" value="0" <?php if(!empty($package)): ?>
                        <?php if($package->is_active == 0): ?>
                            checked="" <?php endif; ?>
                        <?php endif; ?>
                        >
                        Tidak Aktif
                        <i class="input-helper"></i>
                    </label>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label"></label>
            <div class="col-sm-9">
                <button type="submit" class="btn btn-lg btn-gradient-danger mb-2">Save</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/backend/package/form/_form.blade.php ENDPATH**/ ?>