<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="UTF-8" />
    
    <meta name="viewport"
        content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width, height=device-height, target-densitydpi=device-dpi">

    <meta property="og:site_name" content="Godevi">
    <meta property="og:title" content="<?php echo e($title ?? 'GODEVI - Authentic Village Experiences'); ?>" />
    <meta property="og:description" content="<?php echo e($content ?? 'Automatic Approve Payment'); ?>" />
    <meta property="og:image" itemprop="image" content="<?php echo e($image ?? url('assets/customer/frontdata/images/bird.png')); ?>">
    <meta property="og:type" content="website" />
    <meta property="og:updated_time" content="1440432930" />

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e(config('app.name', 'Godesination Village')); ?></title>
    <link rel="icon" href="<?php echo e(url('assets/customer/img/favicon.png')); ?>" type="image/png" />


</head>

<body>
    <script src="<?php echo e(config('midtrans.uri')); ?>" data-client-key="<?php echo e(config('midtrans.client_key')); ?>">
    </script>
    <script>
        window.snap.embed('<?php echo e($snapToken); ?>', {
            embedId: 'snap-container',
            // Optional
            onSuccess: function(result) {
                /* You may add your own js here, this is just example */
                // document.getElementById('result-json').innerHTML += JSON.stringify(result, null, 2);
                console.log(result);
            },
            // Optional
            onPending: function(result) {
                /* You may add your own js here, this is just example */
                // document.getElementById('result-json').innerHTML += JSON.stringify(result, null, 2);
                console.log(result);
            },
            // Optional
            onError: function(result) {
                /* You may add your own js here, this is just example */
                // document.getElementById('result-json').innerHTML += JSON.stringify(result, null, 2);
                console.log(result);
            },
            onClose: function(){
                /* You may add your own implementation here */
            }
        });
    </script>
</body>

</html>
<?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/midtrans/payment.blade.php ENDPATH**/ ?>