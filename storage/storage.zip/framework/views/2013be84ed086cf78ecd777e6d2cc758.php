<button class="btn btn-sm btn-outline-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action</button>
<div class="dropdown-menu">
	<?php $file_name = ''; ?>
	<?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php $file_name = $image; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<a class="dropdown-item" href="#" onclick="return put_id(<?php echo e($model->id); ?>)" data-toggle="modal" data-target="#uploadImage">Upload Image</a>
    <?php $__currentLoopData = $url; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a class="dropdown-item" href="<?php echo e($data); ?>/<?php echo e($file_name); ?>" target="_blank"><?php echo e($key); ?></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<!-- The Modal -->
<div class="modal" id="uploadImage">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Upload Image</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <?php echo Form::open(['url' => $form_upload, 'method' => 'post', 'files'=>true]); ?>

	      <!-- Modal body -->
	      <div class="modal-body">
	        <div class="row">
  				<div class="col-md-12">
  					<input type="hidden" name="id" id="id">
  					
			          <input type="file" name="image" class="form-control">
			        
			    </div>
			</div>
	      </div>

	      <!-- Modal footer -->
	      <div class="modal-footer">
	      	<button type="submit" class="btn btn-gradient-danger">Upload</button>
	      </div>
      <?php echo Form::close(); ?>


    </div>
  </div>
</div>

<script type="text/javascript">
function put_id(id)
{
	$('#id').val(id);
}
</script><?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/datatable/_action_modal.blade.php ENDPATH**/ ?>