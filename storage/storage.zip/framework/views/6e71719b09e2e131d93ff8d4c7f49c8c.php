<div class="modal fade editModal"
    data-type="<?php echo e($modalType); ?>"
    data-index="<?php echo e(empty($modalIndex) ? '' : $modalIndex); ?>"
    data-form="<?php echo e(empty($editForm) ? '' : $editForm); ?>"
    style="display: none;">

    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-close">
                    <img class="icon" src="<?php echo e(asset($public.'icons/fail.svg')); ?>" data-dismiss="modal" aria-label="Close">
                </div>
                <h4 class="modal-title js-modal-title"></h4>
            </div>
            <div class="modal-body radius--bottom">
                <?php if( empty($editForm) ? true : $editForm != 'hidden' ): ?>
                    <div class="modal-label">
                        <span class="js-modal-column-label"></span>

                        
                        <?php if($modalType == 'text' || $modalType == 'text-escape'): ?>
                            <input class="form-control js-edit-column-text-val" type="text" name="" required="required" />
                        <?php endif; ?>
                        

                        
                        <?php if($modalType == 'textarea' || $modalType == 'textarea-escape'): ?>
                            <textarea class="form-control js-edit-column-text-val" name="" rows="4" required="required"></textarea>
                        <?php endif; ?>
                        

                        
                        <?php if($modalType == 'textarea-mce'): ?>
                            <textarea id="js-edit-column-textarea-mce-val" class="form-control js-edit-column-text-val js-edit-column-textarea-mce-val" name="" rows="4" required="required"></textarea>
                        <?php endif; ?>
                        
                        
                        
                        <?php if($modalType == 'number' || $modalType == 'currency-escape'): ?>
                            <input class="form-control js-edit-column-text-val" type="number" name="" required="required" />
                        <?php endif; ?>
                        

                        
                        <?php if($modalType == 'dropdown' || $modalType == 'chaindropdown'): ?>
                            <div class="form-group">
                                <?php echo Form::select($dropdownName, $dropdownQuery, null, ['class'=>'form-control select2 js-'.$dropdownName, 'data-history'=>$modalHistory]); ?>

                            </div>
                        <?php endif; ?>

                        
                        <?php if($modalType == 'dropdown-multiple'): ?>
                            <div class="form-group">
                                <?php echo Form::select($dropdownName.'[]', $dropdownQuery, null, ['class'=>'form-control select2 js-'.$dropdownName, 'data-history'=>$modalHistory, 'multiple'=>'multiple']); ?>

                            </div>
                        <?php endif; ?>
                        

                        
                        <?php if($modalType == 'date'): ?>
                            <input type="text" class="form-control pointer js-date" readonly>
                        <?php endif; ?>
                        

                        
                        <?php if($modalType == 'chaindate'): ?>
                            <div class="input-group input-daterange">
                                <input type="text" class="form-control pointer js-chaindate js-date_start" readonly>
                                <div class="input-group-addon">to</div>
                                <input type="text" class="form-control pointer js-chaindate js-date_end" readonly>
                            </div>
                        <?php endif; ?>
                        
                    </div>
                    
                    <div class="modal-label">
                        <span><?php echo app('translator')->get('common.lbl_reason'); ?></span>
                        <textarea class="form-control js-modal-reason-val" name="reason" rows="4" required="required"></textarea><br>
                    </div>
                    
                    <button type="button" class="btn btn-primary box-shadow right-align js-modal-save-btn"><?php echo app('translator')->get('common.btn_save'); ?></button><br><br>
                <?php endif; ?>
                
                <div class="modal-label"><?php echo app('translator')->get('common.history'); ?></div>
                <div class="history js-modal-history">
                    
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div><?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/components/modal-edit.blade.php ENDPATH**/ ?>