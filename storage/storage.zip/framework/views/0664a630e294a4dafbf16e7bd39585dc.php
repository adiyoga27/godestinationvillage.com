<div class="row">
    <div class="col-md-12">

        <?php if(Auth::user()->role_id == 1): ?> 
        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Village (*)</label>
            <div class="col-sm-9">
                <?php echo Form::select('village_id', $villages, null, ['class' => 'selectpicker', 'required' => 'required', 'data-live-search' => 'true']); ?>

                <?php echo $errors->first('village_id', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
    <?php endif; ?>

        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Kategori Homestay (*)</label>
            <div class="col-sm-9">
                <?php echo Form::select('category_id', $categories, null, ['class' => 'selectpicker', 'required' => 'required', 'data-live-search' => 'true']); ?>

                <?php echo $errors->first('category_id', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>



        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Nama Homestay (*)</label>
            <div class="col-sm-9">
                <label>English : </label>
                <?php echo Form::text('name', null, ['class' => 'form-control', 'required' => 'required']); ?>

                <?php echo $errors->first('name', '<p class="text-danger">:message</p>'); ?>

            </div>

        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label"></label>
            <div class="col-sm-9">
                <label>Indonesia : </label>
                <?php echo Form::text('name_id', $packageTranslate->name ?? null, ['class' => 'form-control', 'required' => 'required']); ?>

                <?php echo $errors->first('name_id', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>


        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Deskripsi (*)</label>
            <div class="col-sm-9">
                <label>English : </label>
                <?php echo Form::textarea('description', null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('description', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label"></label>
            <div class="col-sm-9">
                <label>Indonesia : </label>
                <?php echo Form::textarea('description_id', $packageTranslate->description ?? null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('description_id', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Location (*)</label>
            <div class="col-sm-9">
                <label>English : </label>
                <?php echo Form::text('location', null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('location', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label"></label>
            <div class="col-sm-9">
                <label>Indonesia : </label>
                <?php echo Form::text('location_id', $packageTranslate->location ?? null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('location_id', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Harga Paket (*)</label>
            <div class="col-sm-9">
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text bg-danger text-white">IDR</span>
                    </div>
                    <?php echo Form::number('price', null, ['class' => 'form-control', 'required' => 'required']); ?>

                </div>
                <?php echo $errors->first('price', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Harga Diskon (*)</label>
            <div class="col-sm-9">
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text bg-danger text-white">IDR</span>
                    </div>
                    <?php echo Form::number('disc', null, ['class' => 'form-control', 'required' => 'required']); ?>

                </div>
                <?php echo $errors->first('disc', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Facilities</label>
            <div class="col-sm-9">
                <label>English : </label>
                <?php echo Form::textarea('facilities', null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('facilities', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label"></label>
            <div class="col-sm-9">
                <label>Indonesia : </label>
                <?php echo Form::textarea('facilities_id', $packageTranslate->facilities ?? null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('facilities_id', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Additional Activities</label>
            <div class="col-sm-9">
                <label>English : </label>
                <?php echo Form::textarea('additional_activities', null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('additional_activities', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Additional Activities</label>
            <div class="col-sm-9">
                <label>Indonesia : </label>
                <?php echo Form::textarea('additional_activities_id', $packageTranslate->additional_activities ?? null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('additional_activities_id', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Owner Name (*)</label>
            <div class="col-sm-9">
                <?php echo Form::text('owner_name', null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('owner_name', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Check In Time (*)</label>
            <div class="col-sm-9">
                <?php echo Form::text('check_in_time', null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('check_in_time', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Check Out Time (*)</label>
            <div class="col-sm-9">
                <?php echo Form::text('check_out_time', null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('check_out_time', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Additional Notes</label>
            <div class="col-sm-9">
                <label>English : </label>
                <?php echo Form::textarea('additional_notes',  null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('additional_notes', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label"></label>
            <div class="col-sm-9">
                <label>Indonesia : </label>
                <?php echo Form::textarea('additional_notes_id', $packageTranslate->additional_notes ?? null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('additional_notes_id', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
        

        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Default Image</label>
            <div class="col-sm-9">
                <input type="file" name="default_img" class="form-control">
                <?php echo $errors->first('default_img', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>


        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Breakfast(*)</label>
            <div class="col-sm-4">
                <div class="form-check">
                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="is_breakfast" value="1" <?php if(empty($package)): ?> checked=""
                    <?php else: ?>
                        <?php if($package->is_breakfast == 1): ?>
                            checked="" <?php endif; ?>
                        <?php endif; ?>
                        >
                        Aktif
                        <i class="input-helper"></i>
                    </label>
                </div>
            </div>
            <div class="col-sm-5">
                <div class="form-check">
                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="is_breakfast" value="0" <?php if(!empty($package)): ?>
                        <?php if($package->is_breakfast == 0): ?>
                            checked="" <?php endif; ?>
                        <?php endif; ?>
                        >
                        Tidak Aktif
                        <i class="input-helper"></i>
                    </label>
                </div>
            </div>
        </div>
        <?php if(Auth::user()->role_id == 1): ?> 
        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Status (*)</label>
            <div class="col-sm-4">
                <div class="form-check">
                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="is_active" value="1" <?php if(empty($package)): ?> checked=""
                    <?php else: ?>
                        <?php if($package->is_active == 1): ?>
                            checked="" <?php endif; ?>
                        <?php endif; ?>
                        >
                        Aktif
                        <i class="input-helper"></i>
                    </label>
                </div>
            </div>
            <div class="col-sm-5">
                <div class="form-check">
                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="is_active" value="0" <?php if(!empty($package)): ?>
                        <?php if($package->is_active == 0): ?>
                            checked="" <?php endif; ?>
                        <?php endif; ?>
                        >
                        Tidak Aktif
                        <i class="input-helper"></i>
                    </label>
                </div>
            </div>
        </div>
        <?php endif; ?>
      
        <div class="form-group row">
            <label class="col-sm-3 col-form-label"></label>
            <div class="col-sm-9">
                <button type="submit" class="btn btn-lg btn-gradient-danger mb-2">Save</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/backend/homestay/package/form/_form.blade.php ENDPATH**/ ?>