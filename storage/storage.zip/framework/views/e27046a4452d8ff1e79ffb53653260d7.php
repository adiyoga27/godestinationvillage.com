<?php if(session('status')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e(session('error')); ?>


    </div>
<?php endif; ?><?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/components/alert.blade.php ENDPATH**/ ?>