<?php $__env->startSection('content'); ?>
<style>
        .video-card {
      width: 200px;
      margin: 0 10px;
    }

    .video-thumbnail {
      width: 100%;
      height: auto;
    }

    .video-title {
      margin-top: 10px;
      font-size: 14px;
    }

    .iframe-container {
      position: relative;
      overflow: hidden;
      padding-top: 56.25%; /* 16:9 aspect ratio (change if needed) */
    }

    .iframe-container iframe {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
    }

    .slick-prev,
    .slick-next {
      position: absolute;
      top: 50%;
      transform: translateY(-50%);
      /* background: transparent; */
      border: none;
      color: black;
      font-size: 24px;
      z-index: 1;
    }

    .slick-prev {
      left: -30px;
    }

    .slick-next {
      right: -30px;
    }

    .slick-prev:before,
    .slick-next:before {
      display: none;
    }

    .slick-prev:focus,
    .slick-next:focus,
    .slick-prev:hover,
    .slick-next:hover {
      color: #ff0000;
      outline: none;
    }
  </style>

    <style>
        .owl-nav {
            display: none !important;
        }

        @media (max-width: 768px) {
            .home-banner-area img {
                height: 200px;
                object-fit: cover;
            }

            .home-banner-area .carousel-caption {
                display: block;
            }

            .home-banner-area .carousel-caption h1 {
                font-size: 20pt !important;
            }
        }

        .tours-section .slider-item::after {
            position: unset !important;
        }

    </style>
    <!-- start home banner area -->
    <div id="home" class="home-banner-area">
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>

            </ol>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="d-block w-100" src="<?php echo e(url('storage/sliders/slide-1.jpg')); ?>" alt="First slide">
                    <div class="carousel-caption d-block">
                        <h1 class="h3-responsive" style="color:white;">Authentic Village Experience</h1>
                    </div>
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="<?php echo e(url('storage/sliders/slide-2.jpg')); ?>" alt="Second slide">
                    <div class="carousel-caption d-block">
                        <h1 class="h3-responsive" style="color:white;">Local Economic Improvement</h1>
                    </div>
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="<?php echo e(url('storage/sliders/slide-3.jpg')); ?>" alt="Third slide">
                    <div class="carousel-caption d-block">
                        <h1 class="h3-responsive" style="color:white;">Socially Responsible Tourism</h1>
                    </div>
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="<?php echo e(url('storage/sliders/slide-4.jpg')); ?>" alt="Third slide">
                    <div class="carousel-caption d-block">
                        <h1 class="h3-responsive" style="color:white;">Worry Free Travel Service</h1>
                    </div>
                </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>
    <!-- end home banner area -->


    <!-- start tours section -->
    <section id="tours" class="tours-section pt-100 pb-70">
        <div class="container">
            <div class="section-title">
                <h2><?php echo app('translator')->get('Explore Village'); ?></h2>
                <p><?php echo app('translator')->get('Subtitle Explore Village'); ?></p>
            </div>
            <div class="row no-wrap">

                <div class="col col-md-12">
                    <div class="tours-slider owl-carousel mb-30">
                        <?php $__currentLoopData = $tag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="slider-item" onclick="location.href ='<?php echo e(url('category-package/' . $t->id)); ?>';"
                                style="cursor:pointer">

                                
                                <div class="village-card">
                                    <img src="<?php echo e(url('storage/tag/' . $t->image)); ?>" class="village-img" alt="<?php echo e($t->name); ?>">
                                    <div class="village-overlay"></div>
                                    <div class="village-content">
                                        <h3 class="village-title"><?php echo e($t->name); ?></h3>
                                        <p class="village-desc"><?php echo e($t->desc); ?></p>
                                        <span class="explore-btn">Explore Now <i class='bx bx-right-arrow-alt'></i></span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- end tour section -->

    <!-- start destination section -->
    <section id="destination" class="destination-section pt-100 pb-70 bg-light">
        <div class="container">
            <div class="section-title text-center">
                <h2><?php echo app('translator')->get('Our Services'); ?></h2>
                <p><?php echo app('translator')->get('Subtitle Our Services'); ?></p>
            </div>            <div class="row">
                <div class="col-lg-12">
                    <div class="services-slider">
                        <!-- Service 1 -->
                        <div class="px-3 py-4">
                            <div class="modern-card text-center h-100" style="margin-bottom: 10px;">
                                <div class="content">
                                    <a data-toggle="modal" data-target="#internship" style="color: inherit; text-decoration: none;">
                                        <div class="services-icon mb-4">
                                            <img src="<?php echo e(url('assets/customer/img/etc/internship.png')); ?>" class="img-fluid hover-lift mx-auto" style="height: 120px; object-fit: contain;" alt="">
                                        </div>
                                        <h4 class="font-weight-bold" style="font-size: 16px;"><?php echo app('translator')->get('Internship Program'); ?></h4>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- Service 2 -->
                        <div class="px-3 py-4">
                            <div class="modern-card text-center h-100" style="margin-bottom: 10px;">
                                <div class="content">
                                    <a data-toggle="modal" data-target="#perencanaan" style="color: inherit; text-decoration: none;">
                                        <div class="services-icon mb-4">
                                            <img src="<?php echo e(url('assets/customer/img/etc/perencanaan.png')); ?>" class="img-fluid hover-lift mx-auto" style="height: 120px; object-fit: contain;" alt="">
                                        </div>
                                        <h4 class="font-weight-bold" style="font-size: 16px;"><?php echo app('translator')->get('Tourism Planning, Strategy and Revitalization'); ?></h4>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- Service 3 -->
                        <div class="px-3 py-4">
                            <div class="modern-card text-center h-100" style="margin-bottom: 10px;">
                                <div class="content">
                                    <a href="<?php echo e(url('v-portofolio')); ?>" style="color: inherit; text-decoration: none;">
                                        <div class="services-icon mb-4">
                                            <img src="<?php echo e(url('assets/customer/img/etc/portofolio.png')); ?>" class="img-fluid hover-lift mx-auto" style="height: 120px; object-fit: contain;" alt="">
                                        </div>
                                        <h4 class="font-weight-bold" style="font-size: 16px;"><?php echo app('translator')->get('Portofolio'); ?></h4>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- Service 4 -->
                        <div class="px-3 py-4">
                            <div class="modern-card text-center h-100" style="margin-bottom: 10px;">
                                <div class="content">
                                    <a data-toggle="modal" data-target="#projectmanagement" style="color: inherit; text-decoration: none;">
                                        <div class="services-icon mb-4">
                                            <img src="<?php echo e(url('assets/customer/img/etc/kajian.png')); ?>" class="img-fluid hover-lift mx-auto" style="height: 120px; object-fit: contain;" alt="">
                                        </div>
                                        <h4 class="font-weight-bold" style="font-size: 16px;"><?php echo app('translator')->get('Project Management'); ?></h4>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- Service 5 -->
                        <div class="px-3 py-4">
                            <div class="modern-card text-center h-100" style="margin-bottom: 10px;">
                                <div class="content">
                                    <a data-toggle="modal" data-target="#pengembangansdm" style="color: inherit; text-decoration: none;">
                                        <div class="services-icon mb-4">
                                            <img src="<?php echo e(url('assets/customer/img/etc/sdm.png')); ?>" class="img-fluid hover-lift mx-auto" style="height: 120px; object-fit: contain;" alt="">
                                        </div>
                                        <h4 class="font-weight-bold" style="font-size: 16px;"><?php echo app('translator')->get('Human Resources Development'); ?></h4>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- Service 6 -->
                        <div class="px-3 py-4">
                            <div class="modern-card text-center h-100" style="margin-bottom: 10px;">
                                <div class="content">
                                    <a data-toggle="modal" data-target="#branding" style="color: inherit; text-decoration: none;">
                                        <div class="services-icon mb-4">
                                            <img src="<?php echo e(url('assets/customer/img/etc/branding.png')); ?>" class="img-fluid hover-lift mx-auto" style="height: 120px; object-fit: contain;" alt="">
                                        </div>
                                        <h4 class="font-weight-bold" style="font-size: 16px;">Branding Destinasi dan Pemasaran Digital</h4>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- Service 7 -->
                        <div class="px-3 py-4">
                            <div class="modern-card text-center h-100" style="margin-bottom: 10px;">
                                <div class="content">
                                    <a data-toggle="modal" data-target="#tren" style="color: inherit; text-decoration: none;">
                                        <div class="services-icon mb-4">
                                            <img src="<?php echo e(url('assets/customer/img/etc/tren.png')); ?>" class="img-fluid hover-lift mx-auto" style="height: 120px; object-fit: contain;" alt="">
                                        </div>
                                        <h4 class="font-weight-bold" style="font-size: 16px;"><?php echo app('translator')->get('Consumer Trend and Tourism Insight'); ?></h4>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- end destination section -->
    <!-- start blog section -->
    <section id="virtualreality" class="blog-section pt-100 pb-70">
        <div class="container">
            <div class="section-title">
                <h2><?php echo app('translator')->get('Virtual'); ?></h2>
                <p>Witness the Wonders of the Village through an Immersive Virtual Reality Experience that Transports You to a Fascinating World.</p>
                <center> 

                    <video width="100%" controls style="border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); overflow: hidden;">
                        <source src="<?php echo e(url('/')); ?>/storage/videos/vr-godevi.mp4" type="video/mp4">
                        <source src="https://godestinationvillage.com/storage/videos/vr-godevi.mp4" type="video/ogg">
                     </video>
                   </center>
                <br>
                    <center><a href="https://www.vrfmipa.com/meler" class="btn btn-primary"><i class="fa fa-eye" aria-hidden="true"></i> &nbsp Go Virtual</a></center>
            </div>
        
                <div class="row">

        <div class="col-md-12">
               
        </div>
        
        </div>
       
 
    </section>

    <section id="blog" class="blog-section pt-100 pb-70 bg-light">
        <div class="container">
            <div class="section-title">
                <h2><?php echo app('translator')->get('Youtube Channel'); ?></h2>
                <p>Travel has helped us to understand the meaning of life and it has helped us become better people. Each
                    time we travel, we see the world with new eyes.</p>
            </div>
            <!-- <div class="row">
                <div class="embed-responsive embed-responsive-21by9">
                    <iframe width="560" height="315"
                        src="https://www.youtube.com/embed/videoseries?list=PLV0qBmInL2URngCAlIX5EERlJO4k7p6Zg"
                        title="YouTube video player" frameborder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowfullscreen></iframe>
                </div>
            </div> -->

            <!-- <div class="row">
                <div class="col-md-8">
                    <div class="embed-responsive embed-responsive-16by9">
                    <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/videoseries?list=YOUR_PLAYLIST_ID" frameborder="0" allowfullscreen></iframe>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="list-group" id="video-list"></ul>
                </div>
            </div> -->
            <div class="row">
      <div class="col-md-12">
        <div class="iframe-container">
          <iframe id="youtube-iframe" src="https://www.youtube.com/embed/videoseries?list=PLV0qBmInL2URngCAlIX5EERlJO4k7p6Zg" frameborder="0" allowfullscreen></iframe>
        </div>
      </div>
    </div>
    <div class="row mt-3">
      <div class="col-md-12">
      <h4>Playlist Video Godevi</h4>
        <div class="video-slider">
          <!-- Videos will be dynamically populated here -->
        </div>
      </div>
    </div>
    </section>


    <!-- start blog section -->
    <section id="blog" class="blog-section pt-100 pb-70 ">
        <div class="container">
            <div class="section-title">
                <h2><?php echo app('translator')->get('News Blogs'); ?></h2>
                <p><?php echo app('translator')->get('Subtitle Blogs'); ?>.</p>
            </div>
            <div class="row">
                <?php $__currentLoopData = $recent_blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-lg-6">
                        <div class="item-single item-big mb-30">
                            <div class="image">
                                <img src="<?php echo e(url('storage/blogs/' . $rec->post_thumbnail)); ?>"
                                    style="height:100%; width:100%; 
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            object-fit: cover; !important"
                                    alt="<?php echo e($rec->post_title); ?>" />
                            </div>
                            <div class="content">
                                <ul class="info-list">
                                    <li><i class='bx bx-calendar'></i> <?php echo e($rec->created_at); ?>

                                    </li>
                                    <li><i class='bx bx-tag'></i><?php echo e($rec->post_tags); ?></li>
                                </ul>
                                <h3>
                                    <a href="<?php echo e(url('blog/' . $rec->slug)); ?>"><?php echo e($rec->post_title); ?></a>
                                </h3>
                                <p>
                                    <?php echo \Illuminate\Support\Str::words($rec->post_content, 25, '...'); ?>

                                </p>
                                <ul class="list">
                                    <li>
                                        <div class="author">
                                            <img src="<?php echo e(url('storage/users/' . $rec->user->avatar)); ?>" alt="<?php echo e($rec->user->name); ?>">
                                            <span> <?php echo e($rec->user->name); ?></span>
                                        </div>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(url('blog/' . $rec->slug)); ?>" class="btn-primary">Read More</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                <!-- <?php break; ?> -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <!-- <div class="col-lg-6">
                    <div class="row">
                        <?php
                            $firstStep = true;
                        ?>
                        <?php $__currentLoopData = $recent_blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                if ($firstStep) {
                                    $firstStep = false;
                                    continue;
                                }
                            ?>
                            <div class="col-lg-6">
                                <div class="item-single mb-30">
                                    <div class="image">
                                        <img src="<?php echo e(url('storage/blogs/' . $rec->post_thumbnail)); ?>" alt="Demo Image" />
                                    </div>
                                    <div class="content">
                                        <ul class="info-list">
                                            <li><i class='bx bx-calendar'></i> <?php echo e($rec->created_at); ?></li>
                                            <li><i class='bx bx-tag'></i><?php echo e($rec->post_tags); ?></li>
                                        </ul>
                                        
                                        <h3>
                                            <a href="<?php echo e(url('blog/' . $rec->slug)); ?>"><?php echo e($rec->post_title); ?></a>
                                        </h3>
                                        <p>
                                    <?php echo \Illuminate\Support\Str::words($rec->post_content, 25, '...'); ?>

                                </p>
                                        <ul class="list">
                                            <li>
                                                <div class="author">
                                                    <img src="<?php echo e(url('storage/users/' . $rec->user->avatar)); ?>"
                                                        alt="<?php echo e($rec->user->avatar); ?>">
                                                    <span><?php echo e($rec->user->name); ?></span>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div> -->
            </div>
        </div>
    </section>

    <!-- start testimonial-section -->
    <section id="testimonial" class="testimonial-section ptb-100 bg-light">
        <div class="container">
            <div class="section-title">
                <h2><?php echo app('translator')->get('What Our Clients Say'); ?></h2>
                <p>Travel has helped us to understand the meaning of life and it has helped us become better people. Each
                    time we travel, we see the world with new eyes.</p>
                 
            </div>
            <div class="row">
                <div class="col-lg-8 m-auto">
                    <div class="testimonial-slider owl-carousel">

                        <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="modern-testimonial-card">
                                <i class='bx bxs-quote-alt-left quote-icon'></i>
                                <div class="client-content">
                                    <p class="client-text">"<?php echo e($r->comment); ?>"</p>
                                    
                                    <div class="client-profile">
                                        <div class="client-img">
                                            <img src="<?php echo e(url('storage/reviews/' . $r->avatar)); ?>" alt="<?php echo e($r->name); ?>" />
                                        </div>
                                        <div class="client-info text-left">
                                            <h3><?php echo e($r->name); ?></h3>
                                            <span><?php echo e($r->job); ?></span>
                                            <div class="review-stars">
                                                <?php for($i = 1; $i <= $r->rating; $i++): ?>
                                                    <i class='bx bxs-star'></i>
                                                <?php endfor; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="shape">
            <img src="<?php echo e(url('assets/customer/img/shape1.png')); ?>" alt="Background Shape">
        </div>
    </section>
    <!-- end testimonial section -->


    <!-- end blog section -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>
<script>
 $(document).ready(function() {
      // Fetch playlist videos using YouTube Data API
      $.get(
        "https://www.googleapis.com/youtube/v3/playlistItems", {
          part: "snippet",
          maxResults: 10,
          playlistId: 'PLV0qBmInL2URngCAlIX5EERlJO4k7p6Zg',
          key: 'AIzaSyC7kGh6mbXfjYLQMF_dS-WLRF2iscxg7_o'
        },
        function(data) {
          var videoList = "";
          var items = data.items.reverse();
          var x = 0;
          $.each(items, function(index, item) {
            var videoId = item.snippet.resourceId.videoId;
            var thumbnail = item.snippet.thumbnails.medium.url;
            var title = item.snippet.title;

            // Append video card HTML to the list
            videoList += '<div class="video-card">' +
              '<img class="video-thumbnail" src="' + thumbnail + '" data-video-id="' + videoId + '">' +
              '<h5 class="video-title">' + title + '</h5>' +
              '</div>';
                if(x == 0){

                    firstTake(videoId);
                }
              x++;
          });

          // Add video cards to the slider
          $('.video-slider').html(videoList);

          // Initialize the video slider
          $('.video-slider').slick({
            slidesToShow: 3,
            slidesToScroll: 1,
            prevArrow: '<button type="button" class="slick-prev"><i class="fas fa-chevron-left"></i></button>',
            nextArrow: '<button type="button" class="slick-next"><i class="fas fa-chevron-right"></i></button>',
            responsive: [
              {
                breakpoint: 768,
                settings: {
                  slidesToShow: 2
                }
              },
              {
                breakpoint: 576,
                settings: {
                  slidesToShow: 1
                }
              }
            ]
          });

          // Handle click event on video cards
          $('.video-card').on('click', function() {
            var videoId = $(this).find('img').data('video-id');
            var iframe = document.getElementById('youtube-iframe');
            iframe.src = 'https://www.youtube.com/embed/' + videoId + '?autoplay=1';
          });
        }
      );

      // Initialize the services slider
      $('.services-slider').slick({
        slidesToShow: 3,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 3000,
        arrows: true,
        dots: true,
        prevArrow: '<button type="button" class="slick-prev services-prev"><i class="fas fa-chevron-left" style="color: #d81c25; font-size: 24px;"></i></button>',
        nextArrow: '<button type="button" class="slick-next services-next"><i class="fas fa-chevron-right" style="color: #d81c25; font-size: 24px;"></i></button>',
        responsive: [
          {
            breakpoint: 992,
            settings: {
              slidesToShow: 2
            }
          },
          {
            breakpoint: 576,
            settings: {
              slidesToShow: 1,
              arrows: false
            }
          }
        ]
      });

    });

    function firstTake(videoId) {
            var iframe = document.getElementById('youtube-iframe');
            iframe.src = 'https://www.youtube.com/embed/' + videoId + '?autoplay=1';
    }


  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer/layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/customer/home.blade.php ENDPATH**/ ?>