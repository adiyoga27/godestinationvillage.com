<div class="row">
  <div class="col-md-6">
    <div class="form-group row">
      <label class="col-sm-3 col-form-label">Nama Pengguna (*)</label>
      <div class="col-sm-9">
      	<?php echo Form::text('name', null, ['class'=>'form-control', 'required'=>'required']); ?>

        <?php echo $errors->first('name', '<p class="text-danger">:message</p>'); ?>

      </div>
    </div>

    <input type="hidden" name="role_id" value="2">

    <div class="form-group row">
      <label class="col-sm-3 col-form-label">Email (*)</label>
      <div class="col-sm-9">
        <?php echo Form::email('email', null, ['class'=>'form-control', 'required'=>'required']); ?>

    	<?php echo $errors->first('email', '<p class="text-danger">:message</p>'); ?>

      </div>
    </div>

    <div class="form-group row">
      <label class="col-sm-3 col-form-label">Password <?php if(empty($village)): ?>(*)<?php endif; ?></label>
      <div class="col-sm-9">
        <?php echo Form::password('password', ['class'=>'form-control']); ?>

    	<?php echo $errors->first('password', '<p class="text-danger">:message</p>'); ?>

      </div>
    </div>

    <div class="form-group row">
      <label class="col-sm-3 col-form-label">Konfrimasi Password <?php if(empty($village)): ?>(*)<?php endif; ?></label>
      <div class="col-sm-9">
        <?php echo Form::password('password_confirmation', ['class'=>'form-control']); ?>

        <?php if(!empty($village)): ?><small>* Konfirmasi Password harus diisi ketika kolom password terisi</small><?php endif; ?>
     	<?php echo $errors->first('password_confirmation', '<p class="text-danger">:message</p>'); ?>

      </div>
    </div>

    <div class="form-group row">
      <label class="col-sm-3 col-form-label">Telepon (*)</label>
      <div class="col-sm-9">
        <?php echo Form::text('phone', null, ['class'=>'form-control', 'required'=>'required']); ?>

        <?php echo $errors->first('phone', '<p class="text-danger">:message</p>'); ?>

      </div>
    </div>

    <?php if(empty($village)): ?>
        <?php echo $__env->make('backend.village.form._form_create_bank', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('backend.village.form._form_edit_bank', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>

    <div class="form-group row">
      <label class="col-sm-3 col-form-label">Foto</label>
      <div class="col-sm-9">
        <?php echo Form::file('avatar', null, ['class'=>'form-control']); ?>

        <?php echo $errors->first('avatar', '<p class="text-danger">:message</p>'); ?>

      </div>
    </div>

    <div class="form-group row">
      <label class="col-sm-3 col-form-label">Negara</label>
      <div class="col-sm-9">
        <?php echo Form::text('country', null, ['class'=>'form-control']); ?>

        <?php echo $errors->first('country', '<p class="text-danger">:message</p>'); ?>

      </div>
    </div>
    
    <div class="form-group row">
      <label class="col-sm-3 col-form-label">Alamat</label>
      <div class="col-sm-9">
        <?php echo Form::textarea('address', null, ['class'=>'form-control']); ?>

      </div>
    </div>

    <div class="form-group row">
      <label class="col-sm-3 col-form-label">Status (*)</label>
      <div class="col-sm-4">
        <div class="form-check">
          <label class="form-check-label">
            <input type="radio" class="form-check-input" name="is_active" value="1" 
                <?php if(empty($village)): ?>
                    checked=""
                <?php else: ?>
                    <?php if($village->is_active == 1): ?>
                        checked=""
                    <?php endif; ?>
                <?php endif; ?>
            >
            Aktif
          <i class="input-helper"></i></label>
        </div>
      </div>
      <div class="col-sm-5">
        <div class="form-check">
          <label class="form-check-label">
            <input type="radio" class="form-check-input" name="is_active" value="0"
                <?php if(!empty($village)): ?>
                    <?php if($village->is_active == 0): ?>
                        checked=""
                    <?php endif; ?>
                <?php endif; ?>
            >
            Tidak Aktif
          <i class="input-helper"></i></label>
        </div>
      </div>
    </div>

    <div class="form-group row">
      <label class="col-sm-3 col-form-label"></label>
      <div class="col-sm-9">
            <button type="submit" class="btn btn-lg btn-gradient-danger mb-2">Save</button>
      </div>
    </div>
  </div>

  <?php if(empty($village)): ?>
        <?php echo $__env->make('backend.village.form._form_create_village', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('backend.village.form._form_edit_village', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
</div>
<?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/backend/village/form/_form.blade.php ENDPATH**/ ?>