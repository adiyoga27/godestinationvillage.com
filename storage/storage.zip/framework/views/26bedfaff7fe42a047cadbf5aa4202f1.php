<div class="col-md-6">
  <div class="form-group row">
    <label class="col-sm-3 col-form-label">Nama Desa Wisata (*)</label>
    <div class="col-sm-9">
      <?php echo Form::text('village_name', $village->village_detail->village_name, ['class'=>'form-control', 'required'=>'required']); ?>

      <?php echo $errors->first('village_name', '<p class="text-danger">:message</p>'); ?>

    </div>
  </div>

  <div class="form-group row">
    <label class="col-sm-3 col-form-label">Alamat Desa Wisata (*)</label>
    <div class="col-sm-9">
      <?php echo Form::text('village_address', $village->village_detail->village_address, ['class'=>'form-control', 'id'=>'village_address', 'required'=>'required']); ?>

      <?php echo $errors->first('village_address', '<p class="text-danger">:message</p>'); ?>

    </div>
  </div>

  
  <?php echo Form::hidden('lat', $village->village_detail->lat, ['id' => 'lat']); ?>

  <?php echo Form::hidden('lng', $village->village_detail->lng, ['id' => 'lng']); ?>

  

  <div class="form-group row">
    <label class="col-sm-3 col-form-label">Contact Person (*)</label>
    <div class="col-sm-9">
      <?php echo Form::textarea('contact_person', $village->village_detail->contact_person, ['class'=>'form-control']); ?>

      <?php echo $errors->first('contact_person', '<p class="text-danger">:message</p>'); ?>

    </div>
  </div>

  <div class="form-group row">
    <label class="col-sm-3 col-form-label">Deskripsi (*)</label>
    <div class="col-sm-9">
      <?php echo Form::textarea('desc', $village->village_detail->desc, ['class'=>'form-control']); ?>

      <?php echo $errors->first('desc', '<p class="text-danger">:message</p>'); ?>

    </div>
  </div>
</div><?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/backend/village/form/_form_edit_village.blade.php ENDPATH**/ ?>