<div class="row">
    <div class="col-md-12">
        <?php if(Auth::user()->role_id == 1): ?> 
            <div class="form-group row">
                <label class="col-sm-3 col-form-label">Village (*)</label>
                <div class="col-sm-9">
                    <?php echo Form::select('village_id', $villages, null, ['class' => 'selectpicker', 'required' => 'required', 'data-live-search' => 'true']); ?>

                    <?php echo $errors->first('village_id', '<p class="text-danger">:message</p>'); ?>

                </div>
            </div>
        <?php endif; ?>

        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Kategori Event (*)</label>
            <div class="col-sm-9">
                <?php echo Form::select('category_id', $categories, null, ['class' => 'selectpicker', 'required' => 'required', 'data-live-search' => 'true']); ?>

                <?php echo $errors->first('category_id', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>



        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Nama Event (*)</label>
            <div class="col-sm-9">
                <label>English : </label>
                <?php echo Form::text('name', null, ['class' => 'form-control', 'required' => 'required']); ?>

                <?php echo $errors->first('name', '<p class="text-danger">:message</p>'); ?>

            </div>

        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label"></label>
            <div class="col-sm-9">
                <label>Indonesia : </label>
                <?php echo Form::text('name_id', $packageTranslate->name ?? null, ['class' => 'form-control', 'required' => 'required']); ?>

                <?php echo $errors->first('name_id', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>


        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Deskripsi (*)</label>
            <div class="col-sm-9">
                <label>English : </label>
                <?php echo Form::textarea('description', null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('description', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label"></label>
            <div class="col-sm-9">
                <label>Indonesia : </label>
                <?php echo Form::textarea('description_id', $packageTranslate->description ?? null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('description_id', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>

        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Harga Paket (*)</label>
            <div class="col-sm-9">
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text bg-danger text-white">IDR</span>
                    </div>
                    <?php echo Form::number('price', null, ['class' => 'form-control', 'required' => 'required']); ?>

                </div>
                <?php echo $errors->first('price', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Harga Diskon (*)</label>
            <div class="col-sm-9">
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text bg-danger text-white">IDR</span>
                    </div>
                    <?php echo Form::number('disc', null, ['class' => 'form-control', 'required' => 'required']); ?>

                </div>
                <?php echo $errors->first('disc', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>


        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Location (*)</label>
            <div class="col-sm-9">
                <?php echo Form::text('location', null, ['class' => 'form-control', 'placeholder'=> 'Input lokasi event example: Badung, Mengwi Denpasar']); ?>

                <?php echo $errors->first('location', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>

        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Tanggal (*)</label>
            <div class="col-sm-9">
                <?php echo Form::input('dateTime-local','date_event', null, ['class' => 'form-control', 'required' => 'required']); ?>

                <?php echo $errors->first('date_event', '<p class="text-danger">:message</p>'); ?>

                <p style="font-size: 8pt; color:grey">Tekan gambar/icon calendar untuk mempermudah memilih tanggal</p>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Durasi (*)</label>
            <div class="col-sm-9">
                <?php echo Form::text('duration', null, ['class' => 'form-control', 'placeholder'=> 'Input durasi event, example: 5 Hours']); ?>

                <?php echo $errors->first('duration', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Itenaries</label>
            <div class="col-sm-9">
                <label>English : </label>
                <?php echo Form::textarea('interary', null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('interary', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label"></label>
            <div class="col-sm-9">
                <label>Indonesia : </label>
                <?php echo Form::textarea('interary_id', $packageTranslate->itenaries ?? null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('interary_id', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Inclusion</label>
            <div class="col-sm-9">
                <label>English : </label>
                <?php echo Form::textarea('inclusion', null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('inclusion', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label"></label>
            <div class="col-sm-9">
                <label>Indonesia : </label>

                <?php echo Form::textarea('inclusion_id', $packageTranslate->inclusion ?? null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('inclusion_id', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>




        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Additional</label>
            <div class="col-sm-9">
                <label>English : </label>

                <?php echo Form::textarea('additional', null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('additional', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label"></label>
            <div class="col-sm-9">
                <label>Indonesia : </label>

                <?php echo Form::textarea('additional_id', $packageTranslate->term ?? null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('additional_id', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>


        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Default Image</label>
            <div class="col-sm-9">
                <input type="file" name="default_img" class="form-control">
                <?php echo $errors->first('default_img', '<p class="text-danger">:message</p>'); ?>

            </div>
        </div>



        <?php if(Auth::user()->role_id == 1): ?> 
        
        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Status Free(*)</label>
            <div class="col-sm-4">
                <div class="form-check">
                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="is_free" value="1" <?php if(empty($package)): ?> checked=""
                    <?php else: ?>
                        <?php if($package->is_free == 1): ?>
                            checked="" <?php endif; ?>
                        <?php endif; ?>
                        >
                        Aktif
                        <i class="input-helper"></i>
                    </label>
                </div>
            </div>
            <div class="col-sm-5">
                <div class="form-check">
                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="is_free" value="0" <?php if(!empty($package)): ?>
                        <?php if($package->is_free == 0): ?>
                            checked="" <?php endif; ?>
                        <?php endif; ?>
                        >
                        Tidak Aktif
                        <i class="input-helper"></i>
                    </label>
                </div>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label">Status (*)</label>
            <div class="col-sm-4">
                <div class="form-check">
                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="is_active" value="1" <?php if(empty($package)): ?> checked=""
                    <?php else: ?>
                        <?php if($package->is_active == 1): ?>
                            checked="" <?php endif; ?>
                        <?php endif; ?>
                        >
                        Aktif
                        <i class="input-helper"></i>
                    </label>
                </div>
            </div>
            <div class="col-sm-5">
                <div class="form-check">
                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="is_active" value="0" <?php if(!empty($package)): ?>
                        <?php if($package->is_active == 0): ?>
                            checked="" <?php endif; ?>
                        <?php endif; ?>
                        >
                        Tidak Aktif
                        <i class="input-helper"></i>
                    </label>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label"></label>
            <div class="col-sm-9">
                <button type="submit" class="btn btn-lg btn-gradient-danger mb-2">Save</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/backend/events/package/form/_form.blade.php ENDPATH**/ ?>