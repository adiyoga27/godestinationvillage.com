<?php $__env->startSection('content'); ?>
    <!-- start page title area-->
    <div class="page-title-area ptb-100">
        <div data-aos="fade-up" data-aos-offset="100" data-aos-duration="500" class="container aos-init aos-animate">
            <div class="page-title-content">
                <h1><?php echo app('translator')->get('HomeStay'); ?></h1>
                <ul>
                    <li class="item"><a href="/"><?php echo app('translator')->get('Home'); ?></a></li>
                    <li class="item"><a href="#"><i class="bx bx-chevrons-right"></i><?php echo app('translator')->get('HomeStay'); ?></a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="bg-image"><img src="<?php echo e(url('assets/customer/img/page-title-area/homestay.jpg')); ?>" alt="Image"></div>
    </div>
    <!-- end page title area -->
    <!-- start top destination section -->
    <section id="top-destination" class="top-destination-section pt-100 pb-70 bg-light">
        <div class="container">
            <?php if(count($packages) == 0): ?>
            <div class="section-title">
                <h2>COMING SOON</h2>
                <p> Stay tuned for more details, <br>Instagram : <a href="https://www.instagram.com/godestinationvillage/">@godestinationvillage</a> <br> Phone : +62 82 236 803301</p>
            </div>
            <?php endif; ?>
            <div class="row">
                <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pack): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col-lg-4 col-md-6">
                    <div class="item-single mb-50">
                        <div class="image">
                            <img src="<?php echo e(url('storage/homestay/' . $pack->default_img)); ?>" alt="<?php echo e($pack->name); ?>">
                        </div>
                        <div class="content">
                            <span class="location"><i class='bx bx-map'></i><?php echo e($pack->location); ?></span>
                            <h3>
                                <a href="<?php echo e(url('homestay/' . $pack->slug)); ?>"><?php echo e($pack->name); ?></a>
                            </h3>

                            <p>
                                <?php echo e(strip_tags(substr($pack->description, 0, 100))); ?>.
                            </p>
                            <hr>
                            <ul class="list">
                                <li><i class='bx bx-group'></i>1 People</li>

                                <?php if(!$pack->paywish): ?>
                                <li><?php echo e($pack->price>0 ? 'Rp '. number_format($pack->price,0) : 'Gratis'); ?></li>
                                <?php else: ?>

                                <li>Pay as you wish
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if(count($packages) > 0): ?>

            <div class="item col-md-12">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="pagination text-center">
                            <?php for($i = 1; $i <= $packages->lastPage(); $i++): ?>
                                <a href="<?php echo e($packages->url($i)); ?>" class="page-numbers <?php if($packages->currentPage() == $i): ?> current <?php endif; ?>">

                                    <?php echo e($i); ?>

                                </a>
                            <?php endfor; ?>
                            <?php if($packages->lastPage() > 0 && $packages->currentPage() < $packages->lastPage()): ?>
                                <a href="<?php echo e($packages->nextPageUrl()); ?>" class="page-numbers">Next</a>
                            <?php endif; ?>

                            
                        </div>
                    </div>
                </div>
                
            </div>
            <?php endif; ?>


            </div>
        </div>
    </section>
    <!-- end top destination section -->
    <!-- end our tour section -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer/layout',array(
'title' => 'Best Offers - GODEVI',
)
, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/customer/homestay.blade.php ENDPATH**/ ?>