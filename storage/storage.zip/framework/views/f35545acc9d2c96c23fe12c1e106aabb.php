<?php $__env->startSection('content-header'); ?>
    <div class="page-header">
        <h3 class="page-title">
          Detail Member
        </h3>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item">Administrator</li>
            <li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(url('administrator/user-member')); ?>">User Member</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e($member->name); ?></li>
          </ol>
        </nav>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <?php if(empty($member->avatar)): ?>
                    <img class="card-img-top" src="<?php echo e(url('assets/customer/dist/images/faces/faces1.png')); ?>" alt="image">
                <?php else: ?>
                    <img class="card-img-top" src="<?php echo e(asset('storage/users/'.$member->avatar)); ?>">
                <?php endif; ?>
                <div class="card-body">
                    <h4 class="card-title"><?php echo e($member->name); ?></h4>
                    <p class="card-text">
                        <?php echo e($member->email); ?> <br />
                        <?php echo e($member->phone); ?> <br />
                        <?php echo e($member->address); ?>

                    </p>
                    <a href="<?php echo e(route('user_member.edit', $member->id)); ?>" class="btn btn-danger">Edit Data</a>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h3>Histori Order</h3>
                </div>
                <div class="card-body">
                    <div class="table-responsive"> 
                        <?php echo $html->table(['class'=>'table table-hover', 'style'=>'width:100%']); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php echo $html->scripts(); ?>

<?php echo $__env->make('components/_script_adjust-table', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/backend/member/show.blade.php ENDPATH**/ ?>