<?php
   $public = env('PUBLIC_VARIABLE_URL', "");
?>

<?php echo Form::model($model, ['url' => $delete, 'method' => 'delete', 'class' => 'form-inline js-confirm', 'data-confirm' => $confirm_message, 'onSubmit' => 'event.preventDefault(); return confirmDelete(this)'] ); ?>

    <div class="btn-group btn-group--dart">
        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-table-el="<?php echo e(empty($tableEl) ? '#dataTableBuilder' : $tableEl); ?>" data-padding="<?php echo e(empty($padding) ? '65px' : $padding); ?>" onclick="addPadding(this)">
            Action <span class="caret"></span>
        </button>
        <ul class="dropdown-menu">
            
            <?php $__currentLoopData = $url; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e($data); ?>"><?php echo e($key); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php $__currentLoopData = $additional; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="#" onclick="return confirmStatus('Apakah Anda Yakin?', '<?php echo e($data); ?>')"><?php echo e($key); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php $__currentLoopData = $post_link; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="#" onclick="return notValidate('Apakah Anda Yakin?', '<?php echo e($data); ?>')"><?php echo e($key); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <li>
                <?php echo Form::submit('Hapus', ['class' => 'btn btn-danger']); ?>

            </li>
        </ul>
        
    </div>
<?php echo Form::close(); ?><?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/datatable/_action_dinamyc_add.blade.php ENDPATH**/ ?>