<div class="row">
  <div class="col-md-12">
        <div class="form-group row">
          <label class="col-sm-3 col-form-label">Tipe Diskon (*)</label>
          <div class="col-sm-9">
            <?php echo Form::select('type', [
              '' => 'Pilih Tipe Diskon',
              'fix' => 'FIX',
              'percentage' => 'PERCENTAGE'
            ], null, ['class'=>'selectpicker', 'required'=>'required']); ?>

          <?php echo $errors->first('type', '<p class="text-danger">:message</p>'); ?>

          </div>
        </div>

        <div class="form-group row">
          <label class="col-sm-3 col-form-label">Nilai / Jumlah (*)</label>
          <div class="col-sm-9">
            <?php echo Form::number('value', null, ['class'=>'form-control', 'required'=>'required']); ?>

            <?php echo $errors->first('value', '<p class="text-danger">:message</p>'); ?>

          </div>
        </div>
        <div class="form-group row">
          <label class="col-sm-3 col-form-label">Status (*)</label>
          <div class="col-sm-4">
            <div class="form-check">
              <label class="form-check-label">
                <input type="radio" class="form-check-input" name="is_active" value="1" 
                    <?php if(empty($discount_member)): ?>
                        checked=""
                    <?php else: ?>
                        <?php if($discount_member->is_active == 1): ?>
                            checked=""
                        <?php endif; ?>
                    <?php endif; ?>
                >
                Aktif
              <i class="input-helper"></i></label>
            </div>
          </div>
          <div class="col-sm-5">
            <div class="form-check">
              <label class="form-check-label">
                <input type="radio" class="form-check-input" name="is_active" value="0"
                    <?php if(!empty($discount_member)): ?>
                        <?php if($discount_member->is_active == 0): ?>
                            checked=""
                        <?php endif; ?>
                    <?php endif; ?>
                >
                Tidak Aktif
              <i class="input-helper"></i></label>
            </div>
          </div>
        </div>
        <div class="form-group row">
          <label class="col-sm-3 col-form-label"></label>
          <div class="col-sm-9">
                <button type="submit" class="btn btn-lg btn-gradient-danger mb-2">Save</button>
          </div>
        </div>
    </div>
</div>
<?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/backend/discount_member/form/_form.blade.php ENDPATH**/ ?>