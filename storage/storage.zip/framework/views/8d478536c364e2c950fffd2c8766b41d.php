<?php $__env->startSection('content-header'); ?>
    <div class="page-header">
        <h3 class="page-title">
          Tambah Kategori Homestay
        </h3>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item">Administrator</li>
            <li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(url('administrator/category')); ?>">Kategori Homestay</a></li>
            <li class="breadcrumb-item active" aria-current="page">Tambah Kategori Homestay</li>
          </ol>
        </nav>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <?php echo Form::open(['url' => route('category-homestay.store'),
                  'method' => 'post', 'files'=>true, 'class'=>'form-sample']); ?>

                    <?php echo $__env->make('backend.homestay.category.form._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/backend/homestay/category/create.blade.php ENDPATH**/ ?>