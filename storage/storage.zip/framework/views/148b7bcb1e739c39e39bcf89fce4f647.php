<?php $__env->startSection('content'); ?>

    <!-- start page title area-->
    <div class="page-title-area ptb-100">
        <div class="container">
            <div class="page-title-content">
                <h1><?php echo app('translator')->get('Blog'); ?></h1>
                <ul>
                    <li class="item"><a href="index.html"><?php echo app('translator')->get('Blog'); ?></a></li>
                    <li class="item"><a href="#"><i class='bx bx-chevrons-right'></i>Details</a></li>
                </ul>
            </div>
        </div>
        <div class="bg-image">
            <img src="<?php echo e(url('assets/customer/img/page-title-area/blog-style3.jpg')); ?>" alt=" Demo Image">
        </div>
    </div>


    <!-- start blog details section -->
    <section class="blog-details-section pt-100 pb-70">
        <div class="container">

            <div class="row">
                <div class="col-lg-8 col-md-12">
                    <div class="blog-details-desc mb-30">
                        <div class="image mb-20">
                            <img src="<?php echo e(url('storage/blogs/' . $blog->post_thumbnail)); ?>" alt="image" />
                        </div>
                        <ul class="info-list mb-20">
                            <li><i class='bx bx-calendar'></i> <?php echo e($blog->created_at); ?></li>
                            <li><i class='bx bx-tag'></i>Tour, Tourism, Travel</li>
                        </ul>
                        <div class="content mb-20">
                            <h3><?php echo e($blog->post_title); ?></h3>

                            <?php echo $blog->post_content; ?>


                        </div>

                        <!-- Comments Area -->
                        <div class="comments-area mt-5">
                            <h3 class="comments-title"><?php echo e(count($comments)); ?> Comments:</h3>
                            <ol class="comment-list" style="list-style: none; padding-left: 0;">
                                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="comment" style="margin-bottom: 20px; border-bottom: 1px solid #eee; padding-bottom: 20px;">
                                    <article class="comment-body" style="display: flex;">
                                        <div class="comment-author vcard" style="margin-right: 15px;">
                                            <img src="<?php echo e($comment->users && $comment->users->avatar ? url('storage/users/'.$comment->users->avatar) : asset('customer/img/user1.jpg')); ?>" class="avatar" alt="image" style="width: 50px; height: 50px; border-radius: 50%; object-fit: cover;">
                                        </div>
                                        <div class="comment-content">
                                            <div class="comment-metadata">
                                                <b class="fn"><?php echo e($comment->users ? $comment->users->name : 'Anonymous'); ?></b>
                                                <span class="says" style="color: #666; font-size: 14px;"> - <?php echo e($comment->created_at->format('F d, Y h:i a')); ?></span>
                                            </div>
                                            <div class="comment-text" style="margin-top: 5px;">
                                                <p><?php echo e($comment->comment); ?></p>
                                            </div>
                                        </div>
                                    </article>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ol>
                            
                            <div class="comment-respond mt-5">
                                <?php if(session('success')): ?>
                                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                                <?php endif; ?>
                                <?php if(session('error')): ?>
                                    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                                <?php endif; ?>

                                <?php if(auth()->guard()->check()): ?>
                                    <h3 class="comment-reply-title">Leave a Reply</h3>
                                    <form class="comment-form" action="<?php echo e(url('blog/comment/'.$blog->slug)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <label for="comment">Comment</label>
                                            <textarea name="comment" class="form-control" id="comment" cols="45" rows="5" required="required"></textarea>
                                        </div>
                                        <div class="form-submit mt-3">
                                            <input type="submit" name="submit" id="submit" class="btn btn-primary" value="Post Comment">
                                        </div>
                                    </form>
                                <?php else: ?>
                                     <div class="alert alert-info">Please <a href="<?php echo e(url('user/login')); ?>">Login</a> to leave a comment.</div>
                                <?php endif; ?>
                            </div>
                        </div>
                        </div>
                    </div>
                

                <div class="col-lg-4 col-md-12">
                    <aside class="widget-area">

                        <div class="widget widget-search mb-30">
                            <form class="search-form search-top">
                                <input type="search" class="form-control" placeholder="Search..." />
                                <button type="submit" class="btn-text-only">
                                    <i class='bx bx-search-alt'></i>
                                </button>
                            </form>
                        </div>
                        <div class="widget widget-video mb-30">
                            <div class="video-image">
                                <img src="https://img.youtube.com/vi/kIFVo2qgI-g/sddefault.jpg" width="900px" width="600px"
                                    alt="video" />
                            </div>
                            <a href="https://www.youtube.com/watch?v=kIFVo2qgI-g" class="youtube-popup video-btn">
                                <i class='bx bx-right-arrow'></i>
                            </a>
                        </div>
                        <div class="widget widget-article mb-30">
                            <h3 class="sub-title">Popular Blog</h3>
                            <?php $__currentLoopData = $recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <article class="article-item">
                                    <div class="image">
                                        <img src="<?php echo e(url('storage/blogs/' . $rec->post_thumbnail)); ?>" alt="Demo Image" />
                                    </div>
                                    <div class="content">
                                        <h3>
                                            <a href="<?php echo e(url('blog/' . $rec->slug)); ?>"><?php echo e($rec->post_title); ?></a>
                                        </h3>
                                        <ul class="list">
                                            <li>
                                                <div class="author">
                                                    <img src="<?php echo e(url('storage/users/' . $rec->user->avatar)); ?>"
                                                        alt="Demo Image">
                                                    <span>By - <?php echo e($rec->user->name); ?></span>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </article>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>


                        <div class="widget widget-gallery mb-30">
                            <h3 class="sub-title">Instagram Post</h3>
                             <blockquote class="instagram-media" data-instgrm-permalink="https://www.instagram.com/godestinationvillage/" data-instgrm-version="13"></blockquote>
                            <script async src="//www.instagram.com/embed.js"></script>
                        </div>
                    </aside>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer/layout',array(
'title' => $blog->post_title,
'content'=> strip_tags($blog->post_content),
'image'=> url('storage/blogs/'.$blog->post_thumbnail))
, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/customer/detail-blog.blade.php ENDPATH**/ ?>