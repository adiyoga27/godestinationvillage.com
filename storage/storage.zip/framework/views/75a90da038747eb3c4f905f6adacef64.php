<?php
   $public = env('PUBLIC_VARIABLE_URL', "");
?>


    <div class="btn-group btn-group--dart">
        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-table-el="<?php echo e(empty($tableEl) ? '#dataTableBuilder' : $tableEl); ?>" data-padding="<?php echo e(empty($padding) ? '65px' : $padding); ?>" onclick="addPadding(this)">
            Action <span class="caret"></span>
        </button>
        <ul class="dropdown-menu">
            
            <?php $__currentLoopData = $url; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e($data); ?>"><?php echo e($key); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php $__currentLoopData = $additional; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="#" onclick="return confirmStatus('Apakah Anda Yakin?', '<?php echo e($data); ?>')"><?php echo e($key); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php $__currentLoopData = $post_link; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="#" onclick="return notValidate('Apakah Anda Yakin?', '<?php echo e($data); ?>')"><?php echo e($key); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            
        </ul>
        
    </div>
<?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/datatable/_action_dinamyc_add_without_delete.blade.php ENDPATH**/ ?>