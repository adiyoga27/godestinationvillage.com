<?php $__env->startSection('content-header'); ?>
    <div class="page-header">
        <h3 class="page-title">
          Tambah Paket Event
        </h3>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item">Administrator</li>
            <li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(url('administrator/events')); ?>">Paket Event</a></li>
            <li class="breadcrumb-item active" aria-current="page">Tambah Paket Event</li>
          </ol>
        </nav>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <?php echo Form::open(['url' => route('events.store'),
                  'method' => 'post', 'files'=>true, 'class'=>'form-sample']); ?>

                    <?php echo $__env->make('backend.events.package.form._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script src="<?php echo e(asset('tinymce/js/tinymce/tinymce.min.js')); ?>"></script>
  <script type="text/javascript">
    tinymce.init({
      selector: "textarea",theme: "modern",
      plugins: [
           "advlist autolink link image lists charmap print preview hr anchor pagebreak",
           "searchreplace wordcount visualblocks visualchars insertdatetime media nonbreaking",
           "table contextmenu directionality emoticons paste textcolor responsivefilemanager code"
     ],
     toolbar1: "undo redo | bold italic underline | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | styleselect",
     toolbar2: "| responsivefilemanager | link unlink anchor | image media | forecolor backcolor  | print preview code ",
     image_advtab: true ,
     
     
     filemanager_title:"Responsive Filemanager" ,
     }/library/rm/tinymce/plugins/responsivefilemanager/plugin.min.js"}
   });
    $("#review").rating();
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/backend/events/package/create.blade.php ENDPATH**/ ?>