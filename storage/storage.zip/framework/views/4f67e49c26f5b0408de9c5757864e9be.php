<?php
   $public = env('PUBLIC_VARIABLE_URL', "");
?>

<?php echo Form::model($model, ['url' => $form_url, 'method' => 'delete', 'class' => 'form-inline js-confirm', 'data-confirm' => $confirm_message] ); ?>

	<a href="<?php echo e($show_url); ?>" title="<?php echo app('translator')->get('common.title_show'); ?>">
        <img class="icon" src="<?php echo e(asset($public.'icons/show.svg')); ?>">
    </a>
    <a href="<?php echo e($edit_url); ?>" title="<?php echo app('translator')->get('common.title_edit'); ?>">
        <img class="icon" src="<?php echo e(asset($public.'icons/edit.svg')); ?>">
    </a>
    <button title="<?php echo app('translator')->get('common.title_delete'); ?>" type="submit" class="btn-link">
        <img class="icon" src="<?php echo e(asset($public.'icons/delete.svg')); ?>">
    </button>
    <!-- <?php echo Form::submit('Delete', ['class'=>'btn btn-danger']); ?>  -->
<?php echo Form::close(); ?>

<?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/datatable/_action_complete_with_show.blade.php ENDPATH**/ ?>