<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title><?php echo e(config('app.name', 'Wijaya Musik - Admin')); ?></title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo e(url('assets/customer/dist/vendors/iconfonts/mdi/css/materialdesignicons.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('assets/customer/dist/vendors/css/vendor.bundle.base.css')); ?>">
  <!-- endinject -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo e(url('assets/customer/dist/css/style.css')); ?>">
  <!-- endinject -->
  <link rel="apple-touch-icon" sizes="57x57" href="<?php echo e(asset('favicons/apple-icon-57x57.png')); ?>">
  <link rel="apple-touch-icon" sizes="60x60" href="<?php echo e(asset('favicons/apple-icon-60x60.png')); ?>">
  <link rel="apple-touch-icon" sizes="72x72" href="<?php echo e(asset('favicons/apple-icon-72x72.png')); ?>">
  <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('favicons/apple-icon-76x76.png')); ?>">
  <link rel="apple-touch-icon" sizes="114x114" href="<?php echo e(asset('favicons/apple-icon-114x114.png')); ?>">
  <link rel="apple-touch-icon" sizes="120x120" href="<?php echo e(asset('favicons/apple-icon-120x120.png')); ?>">
  <link rel="apple-touch-icon" sizes="144x144" href="<?php echo e(asset('favicons/apple-icon-144x144.png')); ?>">
  <link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(asset('favicons/apple-icon-152x152.png')); ?>">
  <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('favicons/apple-icon-180x180.png')); ?>">
  <link rel="icon" type="image/png" sizes="192x192"  href="<?php echo e(asset('favicons/android-icon-192x192.png')); ?>">
  <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('favicons/favicon-32x32.png')); ?>">
  <link rel="icon" type="image/png" sizes="96x96" href="<?php echo e(asset('favicons/favicon-96x96.png')); ?>">
  <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('favicons/favicon-16x16.png')); ?>">
  <link rel="manifest" href="<?php echo e(asset('favicons/manifest.json')); ?>">
  <meta name="msapplication-TileColor" content="#ffffff">
  <meta name="msapplication-TileImage" content="<?php echo e(asset('favicons/ms-icon-144x144.png')); ?>">
  <meta name="theme-color" content="#ffffff">

  
  <style type="text/css">
    .navbar.default-layout-navbar .navbar-brand-wrapper .navbar-brand img {
      max-width: 100%;
      height: 60px;
      margin: auto;
      vertical-align: middle;
      margin-left: 10px;
    }

    .navbar.default-layout-navbar .navbar-brand-wrapper .brand-logo-mini img {
      width: 100%;
    }
  </style>

  <?php echo $__env->yieldContent('style'); ?>
</head>
<body>
  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper">
      <div class="content-wrapper d-flex align-items-center auth">
        <?php echo $__env->yieldContent('content'); ?>
      </div>
      <!-- content-wrapper ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="<?php echo e(url('assets/customer/dist/vendors/js/vendor.bundle.base.js')); ?>"></script>
  <script src="<?php echo e(url('assets/customer/dist/vendors/js/vendor.bundle.addons.js')); ?>"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="<?php echo e(url('assets/customer/dist/js/off-canvas.js')); ?>"></script>
  <script src="<?php echo e(url('assets/customer/dist/js/misc.js')); ?>"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?php echo e(url('assets/customer/dist/js/dashboard.js')); ?>"></script>
  <!-- End custom js for this page-->
  <?php echo $__env->yieldContent('js'); ?>
</body>

</html>
<?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/layouts/auth.blade.php ENDPATH**/ ?>