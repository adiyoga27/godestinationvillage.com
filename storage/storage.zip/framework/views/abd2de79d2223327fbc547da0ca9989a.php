<?php $__env->startSection('style'); ?>
<style>
@media print {
    footer {
        display: none;
    }

    nav {
        display: none;
    }

    .btn {
        display: none;
    }

    .navbar {
        display: none !important;
    }

    label {
        display: none !important;
    }
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
function printDiv(divName) {
    window.print();  
}
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
<div class="row">
    <div class="col-lg-12">
        
        <button class="btn btn-lg btn-gradient-danger mb-2 float-right" onclick="printDiv('print');"><i class="mdi mdi-printer"></i> Print Invoice</button>
        
        <h1>Invoice</h1>
        <?php if(Auth::user()->role_id == 1 && $order->payment_status == 'pending'): ?>
            <br />
            <a href="<?php echo e(route('order-event.change_status', ['id'=>$order->id, 'status'=>'cancel'])); ?>" onclick="return confirm('Anda Yakin?')" class="btn btn-lg btn-danger mb-2 float-right"><i class="mdi mdi-close"></i> Cancel</a> 
            <a href="<?php echo e(route('order-event.change_status', ['id'=>$order->id, 'status'=>'success'])); ?>" onclick="return confirm('Anda Yakin?')" class="btn btn-lg btn-success mb-2 float-right"><i class="mdi mdi-check"></i> Verifikasi</a> 
        <?php endif; ?>
    </div>
</div>
<br />
<div class="card" id="print">
  <div class="card-header">
  Order No. :
  <strong><?php echo e($order->code); ?></strong> 
    <span class="float-right"> <strong>Order Date :</strong> <?php echo e(date('d/m/Y', strtotime($order->created_at))); ?></span>
  </div>
  <div class="card-body">
    <div class="row mb-4">
        <div class="col-sm-12">
            <span><strong>Arrival Date :</strong> <?php echo e(date('d/m/Y', strtotime($order->checkin_date))); ?></span><br /><br /><br />
        </div>
        <div class="col-sm-6">
            <h6 class="mb-3">Customer:</h6>
            <div>
                <strong><?php echo e($order->customer_name); ?></strong>
            </div>
            <div><?php echo e($order->customer_address); ?></div>
            <div>Email: <?php echo e($order->customer_email); ?></div>
            <div>Phone : <?php echo e($order->customer_phone); ?></div>
        </div>
        
        <div class="col-sm-6">
            <div>
                <strong><?php echo e(env('APP_NAME')); ?></strong>
            </div>
            <div>Jln Wr Supratman No. 302 Denpasar Timur, Bali</div>
            <div>Website: <?php echo e(env('APP_URL')); ?> </div>
            <div>Email : <?php echo e(env('APP_EMAIL')); ?> </div>
            <div>Phone : <?php echo e(env('APP_PHONE')); ?></div>
            <br />
            <h6 class="mb-3">Payment:</h6>
            <div>
                <strong><?php echo e(str_replace('_', ' ', strtoupper($order->payment_type))); ?></strong> &nbsp;&nbsp;
                <?php if($order->payment_status == 'pending'): ?>
                    <label class='badge badge-gradient-warning'>Pending</label>
                <?php elseif($order->payment_status == 'success'): ?>
                    <label class='badge badge-gradient-success'>Success</label>
                <?php elseif($order->payment_status == 'cancel'): ?>
                    <label class='badge badge-gradient-danger'>Declined</label>
                <?php endif; ?>
            </div>
            <?php if($order->payment_type == 'bank_transfer'): ?>
            <div><strong><?php echo e($order->bank_account->bank_name); ?> <?php echo e($order->bank_account->bank_acc_no); ?></strong> a/n <?php echo e($order->bank_account->bank_acc_name); ?></div>
            <?php endif; ?>
        </div>

        <div class="col-sm-12">
            <br />
            <strong>Special Note</strong> : <?php echo $order->special_note; ?>

        </div>
    </div>
    
    <div class="table-responsive-sm">
        <table class="table table-striped">
    
            <tr>
                <td>Name of Event</td>
                <td><?php echo e($order->event_name); ?></td>
            </tr>
            <tr>
                <td>People(s)</td>
                <td><?php echo e($order->pax); ?> Pax</td>
            </tr>
            <tr>
                <td>Price of Event</td>
                <td>Rp <?php echo e(number_format($order->event_price, 2,'.',',')); ?></td>
            </tr>
            <tr>
                <td>Discount</td>
                <td>Rp <?php echo e(number_format($order->event_discount, 2,'.',',')); ?></td>
            </tr>
            <tr>
                <td><strong>Payment Total</strong></td>
                <td><strong>Rp <?php echo e(number_format($order->total_payment, 2,'.',',')); ?></strong></td>
            </tr>
        </table>
    </div>

    </div>
</div>
<br />
<?php if($order->payment_type == 'bank_transfer'): ?>
    <div class="card">
        <div class="card-header">
            <strong>Evidence of transfer</strong>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-sm-12">
                    <strong>Payment Date :</strong> <?php echo e(date('d/m/Y h:i:s', strtotime($order->payment_date))); ?><br /><br />
                </div>

                <div class="col-sm-6">
                    <strong>Sender:</strong>
                    <strong><?php echo e($order->bank_name); ?> <?php echo e($order->bank_acc_no); ?></strong> a/n <?php echo e($order->bank_acc_name); ?>

                </div>

                <div class="col-sm-6">
                    <strong>Receiver:</strong>
                    <strong><?php echo e($order->bank_account->bank_name); ?> <?php echo e($order->bank_account->bank_acc_no); ?></strong> a/n <?php echo e($order->bank_account->bank_acc_name); ?>

                </div>

                <div class="col-sm-12">
                    <br /><br />
                    <strong>Proof of Payment:</strong> <br /><br />
                    <img class="img-responsive" src="<?php echo e(asset('storage/orders/'.$order->payment_img)); ?>">
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.backend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/backend/events/order/show.blade.php ENDPATH**/ ?>