<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/magnific-popup.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <div class="page-header">
        <h3 class="page-title">
          Detail Desa Wisata
        </h3>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item">Administrator</li>
            <li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(url('administrator/user-village')); ?>">User Desa Wisata</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e($village->name); ?></li>
          </ol>
        </nav>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <?php if(empty($village->avatar)): ?>
                    <img class="card-img-top" src="<?php echo e(url('assets/customer/dist/images/faces/faces1.png')); ?>" alt="image">
                <?php else: ?>
                    <img class="card-img-top" src="<?php echo e(asset('storage/users/'.$village->avatar)); ?>">
                <?php endif; ?>
                <div class="card-body">
                    <h4 class="card-title"><?php echo e($village->name); ?></h4>
                    <p class="card-text">
                        <?php echo e($village->email); ?> <br />
                        <?php echo e($village->phone); ?> <br />
                        <?php echo e(strip_tags($village->address)); ?>

                    </p>
                    <a href="<?php echo e(route('user_village.edit', $village->id)); ?>" class="btn btn-danger">Edit Data</a>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card" style="padding: 30px;">
                <nav>
                    <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                        
                        <a class="nav-item nav-link active" id="nav-detail-tab" data-toggle="tab" href="#nav-detail" role="tab" aria-controls="nav-detail" aria-selected="false">Detail Desa Wisata</a>
                        <a class="nav-item nav-link" id="nav-package-tab" data-toggle="tab" href="#nav-package" role="tab" aria-controls="nav-package" aria-selected="true" onclick="return reload_table_package()">Paket Wisata (<?php echo e(count($village->packages)); ?>)</a>
                        <a class="nav-item nav-link" id="nav-order-tab" data-toggle="tab" href="#nav-order" role="tab" aria-controls="nav-order" aria-selected="false" onclick="return reload_table_order()">Pemesanan (<?php echo e(count($village->village_orders)); ?>)</a>
                    </div>
                </nav>

                <div class="tab-content" id="nav-tabContent">

                    <div class="tab-pane fade show active" id="nav-detail" role="tabpanel" aria-labelledby="nav-detail-tab">
                        <br />
                        <h3 align="center">Informasi Desa Wisata</h3><br />
                        <table class="table nowrap table-hover dataTables no-footer" style="white-space:nowrap; width: 100%">
                            <tr>
                                <td>Nama Desa Wisata</td>
                                <td><?php echo e($village->village_detail->village_name); ?></td>
                            </tr>
                            <tr>
                                <td>Alamat Desa Wisata</td>
                                <td><?php echo e($village->village_detail->village_address); ?></td>
                            </tr>
                            <tr>
                                <td>Contact Person</td>
                                <td><?php echo $village->village_detail->contact_person; ?></td>
                            </tr>
                            <tr>
                                <td>Deskripsi</td>
                                <td><?php echo $village->village_detail->desc; ?></td>
                            </tr>
                            <tr>
                                <td>Akun Bank</td>
                                <td>
                                    <?php echo e($village->village_detail->bank_acc_no); ?> <br /><br />
                                    a/n <?php echo e($village->village_detail->bank_acc_name); ?> <br /><br />
                                    <?php echo e($village->village_detail->bank_name); ?>

                                </td>
                            </tr>
                        </table>
                        <!-- <div id="map" style="width: 100%; height: 300px;"></div> -->
                    </div>

                    <div class="tab-pane fade show" id="nav-package" role="tabpanel" aria-labelledby="nav-package-tab">
                        <br /><br />
                        <table id="package-table" class="table nowrap table-hover dataTables no-footer" style="white-space:nowrap; width: 100%">
                            <thead>
                                <tr>
                                    
                                    <th>No</th>
                                    <th>Kategori</th>
                                    <th>Nama Paket</th>
                                    <th>Harga Paket</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                        </table>
                    </div>

                    <div class="tab-pane fade show" id="nav-order" role="tabpanel" aria-labelledby="nav-order-tab">
                        <br /><br />
                        <table id="order-table" class="table nowrap table-hover dataTables no-footer" style="white-space:nowrap; width: 100%">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th>No</th>
                                    <th>No. Order</th>
                                    <th>Tanggal Dibuat</th>
                                    <th>Nama Paket</th>
                                    <th>Total Pembayaran</th>
                                    <th>Metode Pembayaran</th>
                                    <th>Status Pembayaran</th>
                                </tr>
                            </thead>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php echo $__env->make('backend/village/script/show_js', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/backend/village/show.blade.php ENDPATH**/ ?>