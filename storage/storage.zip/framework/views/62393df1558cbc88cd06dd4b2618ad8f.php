<?php $__env->startSection('content'); ?>
    <!-- start page title area-->
    <div class="page-title-area ptb-100">
        <div class="container">
            <div class="page-title-content">
                <h1>Portofolio</h1>
                <ul>
                    <li class="item"><a href="/">Home</a></li>
                    <li class="item"><a href="#"><i class='bx bx-chevrons-right'></i>Portofolio</a></li>
                </ul>
            </div>
        </div>
        <div class="bg-image">
            <img src="<?php echo e(url('assets/customer/img/page-title-area/founding-timenile.jpg')); ?>" alt="Demo Image" style="background-repeat: no-repeat;
            background-size: auto;">
        </div>
    </div>
    <!-- end page title area -->

    <!-- start team section -->
    <section id="team" class="team-section ptb-100">
        <div class="container">
            
            <div class="row">

                        <?php $__currentLoopData = $portofolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- column  -->
                            <div class="col-md-6 mb-4">
                                <!-- Row -->
                                <div class="item-single ">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <img src="<?php echo e(url('storage')); ?>/portofolio/<?php echo e($f->attachment); ?>" alt="wrapkit"
                                                class="img-fluid" />
                                        </div>
                                        <div class="col-md-12">
                                            <center>
                                                <h5 class="mt-4 font-weight-medium mb-0"><?php echo e($f->title); ?></h5>
                                                <h6 class="subtitle">( <?php echo e($f->dates); ?> )</h6>
                                            </center>
                                            <div class="ml-4 mr-4 description">
                                                <?php echo $f->description; ?>

                                            </div>
                                            <br>
                                            <center>
                                                <div class="social-link">
                                                    <?php if(!empty($f->attachment)): ?>
                                                        <a href="tel:<?php echo e($f->attachment); ?>" target="_blank">
                                                            <i class='bx bxs-download'></i> Download</a>
                                                    <?php endif; ?>
                                                   


                                                </div>
                                            </center>
                                            <br>
                                        </div>
                                    </div>

                                </div>
                            </div>
                                <!-- Row -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- column  -->
                        <!-- column  -->

                        <!-- column  -->

            </div>
        </div>
    </section>
    <!-- end team section -->
<?php $__env->stopSection(); ?>
<script>
  document.addEventListener("DOMContentLoaded", function() {
        var paragraphs = document.querySelectorAll(".description");

        paragraphs.forEach(function(paragraph) {
            var text = paragraph.textContent;
            var truncatedText = text.slice(0, 200);
            var lastSpaceIndex = truncatedText.lastIndexOf(" ");
            var lastWordTruncated = truncatedText.slice(lastSpaceIndex);
            var isFullText = false;

            if (text.length > 200) {
                var truncatedContent = truncatedText.slice(0, lastSpaceIndex) + "...";
                paragraph.textContent = truncatedContent;

                var readMoreLink = document.createElement("a");
                readMoreLink.textContent = "Read More";
                readMoreLink.setAttribute("href", "#");
                readMoreLink.style.color = "red"; // Set color to red

                readMoreLink.addEventListener("click", function(e) {
                    e.preventDefault();
                    if (isFullText) {
                        paragraph.textContent = truncatedContent + " ";
                        readMoreLink.textContent = "Read More";
                        isFullText = false;
                    } else {
                        paragraph.textContent = text;
                        readMoreLink.textContent = "Hide More";
                        isFullText = true;
                    }
                });

                paragraph.appendChild(readMoreLink);
            }
        });
    });
</script>

<?php echo $__env->make('customer/layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/customer/portofolio.blade.php ENDPATH**/ ?>