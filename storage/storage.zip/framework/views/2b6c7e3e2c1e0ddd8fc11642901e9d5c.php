<?php $__env->startSection('content'); ?>

    <style>
        .section-title p {
            max-width: 100% !important;
        }

    </style>
    <!-- start page title area-->
    <div class="page-title-area ptb-100">
        <div data-aos="fade-up" data-aos-offset="100" data-aos-duration="500" class="container aos-init aos-animate">
            <div class="page-title-content">
                <h1><?php echo app('translator')->get('Explore Village'); ?></h1>
                <ul>
                    <li class="item"><a href="/"><?php echo app('translator')->get('Home'); ?></a></li>
                    <li class="item"><a href="#"><i class="bx bx-chevrons-right"></i><?php echo app('translator')->get('Explore Village'); ?></a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="bg-image"><img src="<?php echo e(url('assets/customer/img/page-title-area/explorer.jpg')); ?>" alt="Image"></div>
    </div>
    <!-- end page title area -->
    <!-- start our tours section -->
    <section id="tours" class="tours-section ptb-100 ">
        <div class="container">
            <div class="section-title">
                <h2><?php echo app('translator')->get('Village Tour'); ?></h2>
                <p><?php echo app('translator')->get('Subtitle Explore Village'); ?></p>
                <p>
            </div>
            <div class="row">
                <?php $__currentLoopData = $village; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6" onclick="location.href =''">
                        <div class="item-single mb-30">
                            <div class="image">
                                <img src="<?php echo e(url('storage/users/' . $val->avatar)); ?>"
                                    style="height:500px; object-fit: cover; !important
                                                                                                                                                                                                                                                                                                                                                                                                            object-fit: cover;"
                                    alt="Demo Image" />
                            </div>
                            <div class="content">

                                <div class="title">
                                    <h3>
                                        <a
                                            href="<?php echo e(url('village/' . ($val->village_detail->slug ?? ''))); ?>"><?php echo e($val->village_detail->village_name ?? ''); ?></a>
                                    </h3>
                                    <p><?php echo e($val->village_detail->village_address ?? ''); ?> </p>
                                </div>

                                
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                
            </div>
        </div>
        <div class="item col-md-12">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="pagination text-center">
    
    
                        <?php for($i = 1; $i <= $village->lastPage(); $i++): ?>
                            <a href="<?php echo e($village->url($i)); ?>" class="page-numbers <?php if($village->currentPage() == $i): ?> current <?php endif; ?>">
    
                                <?php echo e($i); ?>

                            </a>
                        <?php endfor; ?>
                        <?php if($village->lastPage() > 0 && $village->currentPage() < $village->lastPage()): ?>
                            <a href="<?php echo e($village->nextPageUrl()); ?>" class="page-numbers">Next</a>
    
                        <?php endif; ?>
    
                        
                    </div>
                </div>
            </div>
            
        </div>
    </section>
    

    <!-- end our tour section -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer/layout',array(
'title' => 'Explorer Village - GODEVI',
)
, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/kktk6246/projects/godestinationvilliage.com/resources/views/customer/village.blade.php ENDPATH**/ ?>